﻿using Kayala.Core;
using Kayala.Metadata.Fields;
using Kayala.Query;
using Kayala.Services;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace ReportsInSalesPrices
{
	[Service("Отчеты в ценах продажи")]
	public class ReportsInSalesPricesService : BaseService
	{
		[ServiceMethod]
		public void RestReportLoad(out int groupsCount)
		{
			groupsCount = 1;
		}

		[ServiceMethod]
		[Param("Date", FieldTypeId.DateTime, Default = DateForGenerate.EndOfToday)]
		[Param("LinesList", FieldTypeId.SystemObject)]
		[Param("Lines", FieldTypeId.SystemObject)]
		[Param("ShowGoodGroups", FieldTypeId.Boolean, Default = false)]
		[Param("GroupsCount", FieldTypeId.Int32, Default = 1)]
		[Param("Goods", FieldTypeId.LinksToDictionaries, ObjectName = "Товары")]
		[Param("Subdivs", FieldTypeId.LinksToDictionaries, ObjectName = "Склады")]
//		public void RestReportRun(DateTime date, List<string> linesList, List<string> lines, bool showGoodGroups, int groupsCount,
//			[ObjectName("Товары")]IEnumerable<int> goods, [ObjectName("Склады")]IEnumerable<int> subdivs)
		public void RestReportRun(MethodContext context)
		{
			var date = (DateTime)context["Date"];
			var linesList = (IEnumerable<string>)context["LinesList"].GetValue();
			var lines = (IEnumerable<string>)context["Lines"].GetValue();
			var showGoodGroups = (bool)context["ShowGoodGroups"];
			var groupsCount = (int)context["GroupsCount"];
			var goods = (IEnumerable<int>)context["Goods"].GetValue();
			var subdivs = (IEnumerable<int>)context["Subdivs"].GetValue();

			var groupFields = new List<TreeGroup>();
			foreach (var line in linesList)
			{
				switch (line)
				{
					case "Склады":
						if (lines.Contains(line))
							groupFields.Add(new TreeGroup("Склад", false));
						break;
					case "Товары":
						if (lines.Contains(line))
							groupFields.Add(new TreeGroup("Товар", showGoodGroups));
						else if (showGoodGroups)
							groupFields.Add(new TreeGroup("Товар", null, true, true, true, groupsCount - 1));
						break;
				}
			}
			var criteria = CreateRestQuery("Остатки товаров")
				.Select("Товар")
				.Sum("Количество")
				.Sum("Сумма") // criteria.Criteria.SelectSumStub("Сумма продажи"); не работает для sqlite ?
				.OnDate(date);
			foreach (var field in groupFields.Where(g => g.FieldName != "Товар"))
				criteria.Select(field.FieldName);

			IEnumerable<int> goodsCodes = null;
			if (goods != null && goods.Any())
			{
				var filter = QueryHelper.GetAllCodes(AppContext, "Товары", goods);
				criteria.WhereIn("Товар", filter);
				goodsCodes = ExecuteQuery(filter).AsEnumerable().Select(r => (int)r["Code"]).ToList();
			}
			if (subdivs != null && subdivs.Any())
				criteria.WhereIn("Склад", QueryHelper.GetAllCodes(AppContext, "Склады", subdivs));

			var query = ExecuteQuery(criteria);

			var prices = AppContext.Services.GetService<IPrices>().GetSalePrices(date, goodsCodes, null);
			while (query.Read())
			{
				prices.TryGetValue((int)query["Товар"], out decimal price);
				query["Сумма"] = decimal.Round((decimal)query["Количество"] * price, 2, MidpointRounding.AwayFromZero);
			}
			query = query.BuildTree(groupFields.ToArray(), new[] { "Количество", "Сумма" });

			var rep = CreateReport("ОстаткиВценахПродажи.tcr");
			rep.AddSection("Шапка");
			rep.SetParameter("Период", "на: " + date);
			if (subdivs != null && subdivs.Any())
				rep.SetParameter("Склады", "По складам: " + QueryHelper.GetDictNames(AppContext, "Склады", subdivs));
			if (goods != null && goods.Any())
				rep.SetParameter("Товары", "По товарам: " + QueryHelper.GetDictNames(AppContext, "Товары", goods));
			rep.AddSection("Таблица");

			query.ProcessLevels((r, level, group) =>
			{
				if (group == null)
					return;

				var property = r[group.FieldName];
				rep.AddSection(level.ToString(CultureInfo.InvariantCulture));
				var typeName = ((DictionaryField)property.Field).DictionaryName;
				rep.SetParameter("Type", typeName);
				rep.SetParameter("Code", (int)property);
				rep.SetParameter("Код", (int)property);
				rep.SetParameter("Наим", (string)property);
				if (typeName == "Товары")
					rep.SetParameter("Единица", (string)property["Единица измерения"]);

				var qnt = (decimal)r["Количество"];
				var amount = (decimal)r["Сумма"];

				rep.SetParameter("Кол", qnt);
				rep.SetParameter("Цена", qnt != 0 ? amount / qnt : 0m);
				rep.SetParameter("Сум", amount);
			});

			query.ToBegin();
			query.Read();
			rep.AddSection("Подвал");
			rep.SetParameter("Кол", query.Count > 0 ? (decimal)query["Количество"] : 0m);
			rep.SetParameter("Сум", query.Count > 0 ? (decimal)query["Сумма"] : 0m);
		}

		[ServiceMethod]
		public void PrintInvoice(MethodContext context)
		{
			var prnForms = new Dictionary<string, string>
			{
				{ "Приход товаров", "НакладнаяПриход.tcr" },
				{ "Расход товаров", "НакладнаяРасход.tcr" },
				{ "Перемещение товаров", "ПеремещениеТоваровЦП.tcr" }
			};
			var doc = context.DocObject;
			var isIncome = doc.ObjectName == "Приход товаров";
			var isOutcome = doc.ObjectName == "Расход товаров";
			var OperationWriteOff = 6;// Списание
			var OperationReturnOutwards = 3;// Возврат поставщику
			if (isOutcome && (int)doc["Операция"] != OperationWriteOff && (int)doc["Операция"] != OperationReturnOutwards)
			{
				context.Alert("Печать в ценах продажи возможна только при типе расхода 'Списание' или 'Возврат поставщику'.");
				context.Cancel("");
				return;
			}
			var goods = doc.Tables[0].CreateIterator().AsEnumerable().Select(r => (int)r["Товар"]).Union(new[] { 0 }).ToList();
			var prices = AppContext.Services.GetService<IPrices>().GetSalePrices(doc.DocDateTime, goods, null);

			var rep = CreateReport(prnForms[doc.ObjectName]);
			rep.AddSection("Header");
			rep.SetSectionObject(doc);
			var operation = (isIncome || isOutcome) ? $"{(string)doc["Операция"]} в ценах продажи" : "";
			rep.SetParameter("Операция", operation);

			rep.AddSection("TableHeader");
			var totalAmount = 0m;
			var table = doc.Tables[0].CreateIterator();
			while (table.Read())
			{
				var goodCode = (int)table["Товар"];
				var qnt = (decimal)table["Количество"];
				prices.TryGetValue(goodCode, out decimal price);
				var amount = decimal.Round(qnt * price, 2, MidpointRounding.AwayFromZero);
				totalAmount += amount;

				rep.AddSection("TableRow");
				rep.SetSectionObject(table);
				rep.SetParameter("Цена", price);
				rep.SetParameter("Сумма", amount);
			}
			rep.AddSection("Footer");
			rep.SetParameter("Сумма", totalAmount);
		}
	}

	public interface IPrices
	{
		Dictionary<int, decimal> GetSalePrices(DateTime? date, IEnumerable<int> goods, int? pricesType);
	}

}
