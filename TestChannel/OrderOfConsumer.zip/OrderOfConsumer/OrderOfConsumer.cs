using System.IO;
using System.Collections.Generic;
using System;
using System.Linq;
using System.Text;
using Kayala.Objects;
using Kayala.Query;
using Kayala.Services;
using Kayala.UI;
using Kayala.Cache;
using Kayala.Events;
using Kayala.Metadata.Fields;

namespace OrderOfConsumer
{
	public interface IMobileTerminalService
	{
		List<Tuple<int, decimal>> GetSetOfGoods(string id);
	}

	public interface IGoodsDict
	{
		string CheckQntScale(DictionaryObject good, decimal qnt);
	}

	[Service(DocName)]
	public class OrderOfConsumerService : Kayala.Services.BaseService
	{
		private const string DocName = "Заявка покупателя";

		[ServiceMethod]
		public void OnDocCreate()
		{
			Context.DocObject["Выполнить до"] = AppContext.NowDateTime;
		}

		[ServiceMethod]
		public void StatusOfOrderChanged()
		{
			if (Context.DocObject.Status == DocumentStatus.Registered)
			{
				var doc = AppContext.Repository.GetDocument(Context.DocObject.Code);
				doc["Статус заявки"] = Context.DocObject["Статус заявки"];
				if (doc.HaveChanges())
				{
					AppContext.Repository.SaveChanges(doc);
					Context.Console.Write(string.Format(
						GetLocalString("#OrderOfConsumer/OrderOfConsumer/StatusOfOrderSaved"), doc["Статус заявки"]));
				}
			}
		}

		[ServiceMethod]
		public void SetGoodScale([ObjectName("Товары")]DictionaryObject товарТаб, out int scale)
		{
			scale = (int)товарТаб["Единица измерения"]["Точность"];
		}

		[ServiceMethod]
		public void TableInsert([ObjectName("Товары")]DictionaryObject товарТаб, decimal колвоТаб)
		{
			AddRow(товарТаб.Code, колвоТаб);
			SumTable();
		}

		private void AddRow(int good, decimal quantity)
		{
			var table = Context.DocObject.Tables[0];
			table.Add();
			table["Товар"] = good;
			table["Количество"] = quantity;
		}

		private void SumTable()
		{
			Context.DocObject.Tables[0].SumBy(new[] {"Товар"}, new[] {"Количество"});
		}

		[ServiceMethod]
		public void FillContractorGoods()
		{
			var noContrGoods = AppContext.Metadata.GetDictionary("Товары контрагента") == null;
			if (noContrGoods)
			{
				Context.Cancel(GetLocalString("#OrderOfConsumer/OrderOfConsumer/NoModuleContractorGoods"));
				return;
			}
			var criteria = new QueryCriteria("Товары")
				.InnerJoin("Товары контрагента", "Code", "Товар")
				.Select("Code")
				.WhereDictNotDeleted()
				.Where("[Товары контрагента.Владелец] = @contractor and [Товары контрагента.Deleted] = 0", (int)Context.DocObject["Контрагент"])
				.OrderBy("Name");
			var goods = ExecuteQuery(criteria).AsEnumerable()
				.Select(r => (int)r["Code"]).Distinct().ToDictionary(c => c, c => 0m);
			AddGoods(goods);
		}

		[ServiceMethod]
		public void TableAddFromClipboard(IEnumerable<int> codes)
		{
			if (codes?.Any() == true)
			{
				AddGoods(codes.Distinct().ToDictionary(c => c, c => 0m));
			}
		}

		[ServiceMethod]
		public void AddFromTerminal(string sessionId)
		{
			var goods = AppContext.Services.GetService<IMobileTerminalService>().GetSetOfGoods(sessionId);
			if (goods.Count == 0)
			{
				Context.Alert(GetLocalString("#Common/DataFromTerminalIsUnavailable"));
				return;
			}
			AddGoods(goods.ToDictionary(g => g.Item1, g => g.Item2));
		}

		private void AddGoods(Dictionary<int, decimal> goodsQnts)
		{
			if (goodsQnts?.Any() == false)
				return;

			var table = Context.DocObject.Tables[0];
			var oldCount = table.Count;
			foreach (var pair in goodsQnts)
			{
				var good = AppContext.Repository.GetDictionaryItem("Товары", pair.Key);
				if (good != null && !good.IsGroup && !good.IsDeleted)
				{
					AddRow(good.Code, pair.Value);
				}
			}
			if (oldCount != table.Count)
				SumTable();
		}

		[ServiceMethod]
		public void ScannerRead(string scanerData, out System.Data.DataTable scaneredGoods, [ObjectName("Товары")] out DictionaryObject товарТаб)
		{
			scaneredGoods = null;
			товарТаб = null;

			if (string.IsNullOrEmpty(scanerData))
				return;

			var criteria = new QueryCriteria("Штрихкоды")
				.Select("Owner")
				.Where("Name = @name", scanerData)
				.WhereDictNotDeleted();

			var goods = ExecuteQuery(criteria).AsEnumerable().Select(r => (DictionaryObject)r["Owner"]).ToList();
			if (goods.Count == 0)
			{
				Context.Cancel(string.Format(GetLocalString("#Common/GoodWithBarCodeNotFound"), scanerData));
				return;
			}
			if (goods.Count == 1)
			{
				Context["ТоварТаб"] = goods[0].Code;
				return;
			}
			scaneredGoods = new System.Data.DataTable();
			scaneredGoods.Columns.Add("Code", typeof(int));
			scaneredGoods.Columns.Add("Name", typeof(string));
			scaneredGoods.Columns.Add("Unit", typeof(string));
			foreach (var good in goods)
			{
				scaneredGoods.Rows.Add(good.Code, good.Name, (string)good["Единица измерения"]);
			}
		}

		[ServiceMethod]
		public void CheckScaneredGoods(int scaneredIndex, System.Data.DataTable scaneredGoods, out int товарТаб)
		{
			товарТаб = 0;
			if (scaneredGoods?.Rows.Count > 0 && scaneredIndex >= 0)
			{
				товарТаб = (int)scaneredGoods?.Rows[scaneredIndex]["Code"];
			}
		}

		[ServiceMethod]
		public void BeforeProcessDocStart(out bool skipDelZeroQntRows, out List<int> zeroQntRowsIdxs)
		{
			zeroQntRowsIdxs = new List<int>(0);
			var doc = Context.DocObject;
			if (doc.Status == DocumentStatus.Registered)
			{
				skipDelZeroQntRows = true;
				return;
			}
			zeroQntRowsIdxs = doc.Tables[0].CreateIterator().AsEnumerable()
				.Where(t => (decimal)t["Количество"] <= 0)
				.Select(t => (int)t["Номер"] - 1)
				.ToList();
			skipDelZeroQntRows = zeroQntRowsIdxs.Count == 0;
		}

		[ServiceMethod]
		public void BeforeProcessDocEnd(List<int> zeroQntRowsIdxs)
		{
			for (var i = zeroQntRowsIdxs.Count - 1; i > -1; i--)
				Context.DocObject.Tables[0].Remove(zeroQntRowsIdxs[i]);
		}

		[Event(DefaultEvents.ProcessDocument)]
		[ServiceMethod]
		public void ProcessDocument(MethodContext context)
		{
			var eventData = context.EventData as ProcessDocumentEventData;
			if (eventData?.Document.ObjectName != DocName)
				return;

			var doc = eventData.Document;
			if (doc.Status == DocumentStatus.Registered || eventData.ToStatus != DocumentStatus.Registered)
				return;

			var errors = new StringBuilder();

			if (doc["Статус заявки"].IsNull())
				errors.AppendLine(GetLocalString("#OrderOfConsumer/OrderOfConsumer/NeedSelectStatusOfOrder"));

			if (doc["Контрагент"].IsNull())
				errors.AppendLine(GetLocalString("#Common/NeedSelectContractor"));

			var table = doc.Tables[0].CreateIterator();
			if (table.Count == 0)
				errors.AppendLine(GetLocalString("#Common/NeedAddRowsToDoc"));

			while (table.Read())
			{
				var prefix = string.Format(GetLocalString("#Common/RowNumPrefix"), table.Position + 1);
				var qnt = (decimal)table["Количество"];
				if (qnt <= 0)
					errors.AppendLine(prefix + GetLocalString("#Common/NeedEnterQuantity"));
				else
				{
					var msg = AppContext.Services.GetService<IGoodsDict>().CheckQntScale((DictionaryObject)table["Товар"], qnt);
					if (!string.IsNullOrEmpty(msg))
						context.Console.Write(prefix + msg);
				}
			}
			if (errors.Length > 0)
				context.Cancel(errors.ToString());
		}

		[ServiceMethod]
		[Param("EnterOn", FieldTypeId.LinkToAnyDocument)]
		public void EnterOnOutcomeByOrder(MethodContext context)
		{
			var doc = Context.DocObject;
			var enterOn = (DocumentObject)Context["EnterOn"];

			doc["Заявка покупателя"] = enterOn.Code;
			doc["Контрагент"] = enterOn["Контрагент"];
			doc["Комментарий"] = "На основании: " + enterOn;

			var table = doc.Tables[0];
			var basisTbl = enterOn.Tables[0].CreateIterator();
			var prices = basisTbl.Count > 0 ? GetGoodsPrices(basisTbl.AsEnumerable().Select(t => (int)t["Товар"])) : null;
			
			basisTbl.ToBegin();
			while (basisTbl.Read())
			{
				var qnt = (decimal)basisTbl["Количество"] - (decimal)basisTbl["Отгружено"];
				if (qnt > 0)
				{
					table.Add();
					table["Товар"] = basisTbl["Товар"];
					table["Количество"] = qnt;
					decimal price = 0;
					prices?.TryGetValue((int)table["Товар"], out price);
					table["Цена"] = price;
					table["Сумма"] = qnt * price;

					doc.Amount += (decimal)table["Сумма"];
				}
			}
			if (table.Count == 0)
				Context.Console.Write(GetLocalString("#OrderOfConsumer/OrderOfConsumer/NoGoodsAllShipped"));
		}

		private Dictionary<int, decimal> GetGoodsPrices(IEnumerable<int> goods)
		{
			var goodsPrices = AppContext.Services.GetService<IOutcomeGoodsDocPrices>().GetPrices(Context.DocObject, goods);
			return goodsPrices.ToDictionary(i => i.Item1, i => i.Item2);
		}

		[ServiceMethod]
		public void SetOrderOfConsumerText(out string orderOfConsumerText)
		{
			var orderDoc = (DocumentObject)Context.DocObject["Заявка покупателя"];
			orderOfConsumerText = orderDoc?.ToString();
		}

		[ServiceMethod]
		public void OpenOrderDoc()
		{
			var orderDoc = (DocumentObject)Context.DocObject["Заявка покупателя"];
			if (orderDoc != null)
				Context.ObjectsForOpen.Add(orderDoc);
		}

		[Event(DefaultEvents.ProcessDocument)]
		[ServiceMethod]
		public void ProcessOutcomeGoodsDoc(MethodContext context)
		{
			var eventData = context.EventData as ProcessDocumentEventData;
			if (eventData?.Document.ObjectName != "Расход товаров")
				return;

			var doc = eventData.Document;
			var order = (DocumentObject)doc["Заявка покупателя"];
			if (order == null)
				return;

			var register = doc.Status != DocumentStatus.Registered && eventData.ToStatus == DocumentStatus.Registered;
			var unRegister = doc.Status == DocumentStatus.Registered && eventData.ToStatus != DocumentStatus.Registered;
			if (!register && !unRegister)
				return;

			var goodsShippeds = doc.Tables[0].CreateIterator().AsEnumerable()
				.ToDictionary(t => (int)t["Товар"], t => (decimal)t["Количество"]);

			var table = order.Tables[0].CreateIterator();
			while (table.Read())
			{
				decimal shipped;
				if (!goodsShippeds.TryGetValue((int)table["Товар"], out shipped))
					continue;

				var qnt = (decimal)table["Отгружено"] + (register ? shipped : -shipped);
				table["Отгружено"] = qnt > 0 ? qnt : 0;

			}
			AppContext.Repository.SaveChanges(order);
		}
	}

	public interface IOutcomeGoodsDocPrices
	{
		List<Tuple<int, decimal>> GetPrices(DocumentObject doc, IEnumerable<int> goods);
	}
}
