using System;
using System.Collections.Generic;
using System.Linq;
using Kayala.Core;
using Kayala.Metadata.Fields;
using Kayala.Objects;
using Kayala.Query;
using Kayala.Services;
using Kayala.Events;

namespace Delivery
{
	[Service]
	public class DeliveryAcceptanceService : BaseService
	{
		[ServiceMethod]
		public void CreateObject()
		{
            Context.Cancel("Документ создаётся только на основании документов продажи");
		}

        [ServiceMethod]
		[Param("EnterOn", FieldTypeId.LinkToAnyDocument)]
		public void EnterOn(MethodContext context)
		{
			var basisDoc = (DocumentObject)context["EnterOn"];
			var doc = context.DocObject;

            doc["Документ основание"] = basisDoc.Code;
			doc["Контрагент"] = basisDoc["Контрагент"];
			if (!doc["Контрагент"].IsNull())
			{
				doc["Телефон"] = doc["Контрагент"]["Телефон"];
				doc["Адрес"] = doc["Контрагент"]["Адрес"];
			}
			doc["Дата доставки"] = doc.DocDateTime.Date;

			var sourceTable = basisDoc.Tables[0].CreateIterator();
			while(sourceTable.Read())
			{
				doc.Tables[0].Add();
				doc.Tables[0]["Товар"] = sourceTable["Товар"];
				doc.Tables[0]["Количество"] = sourceTable["Количество"];
			}
		}

		[Event(DefaultEvents.ProcessDocument)]
		[ServiceMethod]
		public void ProcessDocument(MethodContext context)
		{
			if (!(context.EventData is ProcessDocumentEventData eventData) || eventData.Document.ObjectName != "Прием в доставку")
				return;

			var doc = eventData.Document;
			if (doc.Status != DocumentStatus.Registered && eventData.ToStatus == DocumentStatus.Registered)
			{
				var reg = AppContext.Repository.CreateRegisterActions("Товары в доставке", doc);
				reg["Документ продажи"] = doc["Документ основание"];
				reg["Документ приёма"] = doc.Code;

				var table = doc.Tables[0].CreateIterator();
				if (table.Count == 0)
				{
					context.Cancel(GetLocalString("#Common/NeedAddRowsToDoc"));
					return;
				}

				while (table.Read())
				{
					reg["Товар"] = table["Товар"];
					reg["Количество"] = table["Количество"];

					reg.AddAction(RegisterAction.Income);
				}
			}
		}
    }

	[Service]
	public class DeliveryService : BaseService
	{
		[ServiceMethod]
		public void CreateObject()
		{
            Context.Cancel("Документ создаётся только на основании документа Прием в доставку");
		}

        [ServiceMethod]
		[Param("EnterOn", FieldTypeId.LinkToAnyDocument)]
		public void EnterOn(MethodContext context)
		{
			var basisDoc = (DocumentObject)context["EnterOn"];
			var doc = context.DocObject;

            doc["Документ основание"] = basisDoc.Code;
            doc["Контрагент"] = basisDoc["Контрагент"];
            doc["Телефон"] = basisDoc["Телефон"];
            doc["Адрес"] = basisDoc["Адрес"];
            doc["Дата доставки"] = basisDoc["Дата доставки"];

			var sourceTable = basisDoc.Tables[0].CreateIterator();
			while(sourceTable.Read())
			{
				doc.Tables[0].Add();
				doc.Tables[0]["Товар"] = sourceTable["Товар"];
				doc.Tables[0]["Количество"] = sourceTable["Количество"];
			}
		}

		[Event(DefaultEvents.ProcessDocument)]
		[ServiceMethod]
		public void ProcessDocument(MethodContext context)
		{
			if (!(context.EventData is ProcessDocumentEventData eventData) || eventData.Document.ObjectName != "Доставка")
				return;

			var doc = eventData.Document;
			if (doc.Status != DocumentStatus.Registered && eventData.ToStatus == DocumentStatus.Registered)
			{
				var reg = AppContext.Repository.CreateRegisterActions("Товары в доставке", doc);
				reg["Документ продажи"] = doc["Документ основание"]["Документ основание"];
				reg["Документ приёма"] = doc["Документ основание"];

				var table = doc.Tables[0].CreateIterator();
				if (table.Count == 0)
				{
					context.Cancel(GetLocalString("#Common/NeedAddRowsToDoc"));
					return;
				}

				while (table.Read())
				{
					reg["Товар"] = table["Товар"];
					reg["Количество"] = table["Количество"];

					reg.AddAction(RegisterAction.Outcome);
				}
			}
		}
    }

	[Service]
	public class DeliveryReportService : BaseService
	{
		[ServiceMethod]
		[Param("Date", FieldTypeId.DateTime, Default = DateForGenerate.EndOfToday)]
		[Param("LinesList", FieldTypeId.SystemObject)]
		[Param("Lines", FieldTypeId.SystemObject)]
		[Param("ShowGoodGroups", FieldTypeId.Boolean, Default = false)]
		[Param("Goods", FieldTypeId.LinksToDictionaries, ObjectName = "Товары")]
		[Param("Contractors", FieldTypeId.LinksToDictionaries, ObjectName = "Контрагенты")]		
		public void Run(MethodContext context)
		{
			var date = (DateTime)context["Date"];
			var lines = (IEnumerable<string>)context["Lines"].GetValue();
			var showGoodGroups = (bool) context["ShowGoodGroups"];
			var goods = (IEnumerable<int>)context["Goods"].GetValue() ?? Array.Empty<int>();
			var contractors = (IEnumerable<int>)context["Contractors"].GetValue() ?? Array.Empty<int>();

			var groupFields = new List<TreeGroup>();
			foreach (var line in (IEnumerable<string>) context["LinesList"].GetValue())
			{
				switch (line)
				{
					case "Документ продажи":
						if (lines.Contains(line))
							groupFields.Add(new TreeGroup("Документ продажи", false));
						break;
					case "Документ приёма":
						if (lines.Contains(line))
							groupFields.Add(new TreeGroup("Документ приёма", false));
						break;
					case "Товары":
						if (lines.Contains(line))
							groupFields.Add(new TreeGroup("Товар", showGoodGroups));
						break;
				}
			}

			var criteria = CreateRestQuery("Товары в доставке")
				.Sum("Количество")
				.Select("Документ приёма")
				.OnDate(date);

			foreach (var field in groupFields.Where(g => g.FieldName != "Документ приёма").Select(g => g.FieldName))
				criteria.Select(field);

			if (goods.Any())
				criteria.WhereIn("Товар", QueryHelper.GetAllCodes(AppContext, "Товары", goods));

			var queryResult = ExecuteQuery(criteria);

			while(queryResult.Read())
			{
				if (!queryResult["Документ приёма"].IsNull())
				{
					var doc = queryResult["Документ приёма"].GetObject();
					if (contractors.Any() && !contractors.Contains((int)doc["Контрагент"]))
					{
						queryResult.RemoveRow(queryResult.Position);
					}
				}
			}

			queryResult.ToBegin();
			if (groupFields.Count > 0)
				queryResult = queryResult.BuildTree(groupFields.ToArray(), new[] {"Количество"});

			var report = CreateReport("ТоварыВДоставке.tcr");
			report.AddSection("Шапка");
			report.SetParameter("ДатаНа", date);
			if (goods.Any())
				report.SetParameter("Товары", QueryHelper.GetDictNames(AppContext, "Товары", goods));
			if (contractors.Any())
				report.SetParameter("Контрагенты", QueryHelper.GetDictNames(AppContext, "Контрагенты", contractors));
			report.AddSection("Таблица");	

			queryResult.ProcessLevels((r, level, group) =>
			{
				if (group == null)
					return;

				var property = r[group.FieldName];
				report.AddSection(level.ToString(System.Globalization.CultureInfo.InvariantCulture));
				report.SetSectionObject(property.GetObject());

				var qnt = (decimal) r["Количество"];

				report.SetParameter("Кол", qnt);
			});

			queryResult.ToBegin();
			queryResult.Read();
			report.AddSection("Подвал");
			if (queryResult.Count > 0)
			{
				report.SetParameter("Кол", (decimal)queryResult["Количество"]);
			}
			else
			{
				report.SetParameter("Кол", 0m);
			}		
		}
    }
}
