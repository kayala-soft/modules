﻿using Kayala.Core;
using Kayala.Database;
using Kayala.Metadata.Fields;
using Kayala.Objects;
using Kayala.Query;
using Kayala.Services;
using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;

namespace ImportService
{
	[Service]
	public class ImportDataService : BaseService
	{
		private const string GoodsDictName = "Товары";
		private const string UnitsDictName = "Единицы измерения";
		private const string BarcodesDictName = "Штрихкоды";
		private const string ContractorsDictName = "Контрагенты";

		private class DictData
		{
			public int MaxCodeObj { get; set; }
			public Dictionary<string, int> GroupsNamesCodes { get; } = new Dictionary<string, int>();
			public Dictionary<string, int> ElementsNamesCodes { get; } = new Dictionary<string, int>();
			public Dictionary<string, int> UnitsNamesCodes { get; set; } = new Dictionary<string, int>();
			public Dictionary<string, int> BarcodesCodes { get; set; } = new Dictionary<string, int>();

			public DictData(Kayala.KAppContext appContext, string dictName)
			{
				var criteria = new QueryCriteria(dictName)
					.Select("Code").Select("Name").Select("IsGroup")
					.OrderBy("Name").OrderBy("Deleted"); // для одинаковых названий возьмем первый НЕудаленный товар/группу
				var query = appContext.Repository.ExecuteQuery(criteria);
				MaxCodeObj = 0;
				while (query.Read())
				{
					var code = (int)query["Code"];
					var name = (string)query["Name"];
					var isGroup = (bool)query["IsGroup"];

					if (isGroup)
					{
						if (!GroupsNamesCodes.ContainsKey(name))
							GroupsNamesCodes.Add(name, code);
					}
					else if (!ElementsNamesCodes.ContainsKey(name))
						ElementsNamesCodes.Add(name, code);

					MaxCodeObj = Math.Max(MaxCodeObj, code);
				}
			}

			public static Dictionary<string, int> GetFieldsCodes(Kayala.KAppContext appContext, MethodContext context, string dictName, string fieldName)
			{
				var criteria = new QueryCriteria(dictName)
					.Select("Code")
					.Select("Deleted")
					.Select(fieldName)
					.OrderBy(fieldName)
					.OrderBy("Deleted")
					.OrderBy("Code"); // для одинаковых названий возьмем первый НЕудаленный элемент
				var query = appContext.Repository.ExecuteQuery(criteria);

				var result = new Dictionary<string, int>();
				while (query.Read())
				{
					var deleted = (bool)query[fieldName];
					var value = (string)query[fieldName];
					if (!deleted || !result.ContainsKey(value))
					{
						result[value] = (int)query["Code"];
					}
				}
				return result;
			}
		}

		[ServiceMethod]
		public void Run(string fileName, int tabPageIndex)
		{
			if (NotExistsFile(fileName))
				return;

			DataTable data = GetDataFromFile(fileName);
			if (data == null)
				return;

			if (tabPageIndex == 0)
			{
				ImportGoods(data);
			}
			else
			{
				ImportContractors(data);
			}
			Context.Alert("Выполнено.");
		}

		private void ImportGoods(DataTable data)
		{
			const int nameColIdx = 0;
			const int groupColIdx = 1;
			const int unitColIdx = 2;
			const int barcodeColIdx = 3;
			const int quantityColIdx = 4;
			const int priceInColIdx = 5;
			const int priceOutColIdx = 6;

			var dictData = new DictData(AppContext, GoodsDictName)
			{
				UnitsNamesCodes = DictData.GetFieldsCodes(AppContext, Context, UnitsDictName, "Name"),
				BarcodesCodes = DictData.GetFieldsCodes(AppContext, Context, BarcodesDictName, "Name")
			};

			// проверяем дополнительные поля
			List<Tuple<int, string>> otherIdxsFields = GetOtherIdxsFields(priceOutColIdx + 1, data, GoodsDictName);

			var income = AppContext.Repository.CreateDocument("Приход товаров");
			income.GenerateNumber();
			const int izlishki = 2;
			income["Операция"] = izlishki;
			income["Склад"] = CreateSore();

			var pricing = AppContext.Repository.CreateDocument("Ценообразование");
			pricing.GenerateNumber();

			var count = 0;
			var nameMaxLength = ((StringField)AppContext.Metadata.Dictionaries.First(d => d.ObjectName == GoodsDictName).GetFieldByDbName("Name")).MaxLength;
			foreach (var row in data.AsEnumerable().Where(r => r[nameColIdx] != DBNull.Value))
			{				
				var name = string.Join(" ", GetValueAsString(row, nameColIdx).Split(new []{' '}, StringSplitOptions.RemoveEmptyEntries));
				if (name.Length == 0)
					continue;

				name = name.Truncate(nameMaxLength);

				var unit = GetUnit(GetValueAsString(row, unitColIdx), dictData.UnitsNamesCodes);
				if (unit <= 0)
					unit = GetUnit("шт", dictData.UnitsNamesCodes);

				DictionaryObject parent = null;
				var groupName = GetValueAsString(row, groupColIdx);
				if (groupName.Length > 0)
				{
					parent = GetGroup(groupName, unit, dictData.GroupsNamesCodes);
				}
				var barcodes = GetValueAsString(row, barcodeColIdx).Split(new[] { ',', ';', ' ' }, StringSplitOptions.RemoveEmptyEntries)
					.Select(b => b.Trim()).Where(b => b.Length > 0).ToList();

				DictionaryObject good = null;
				// ищем по наименованию
				int code;
				if (good == null && dictData.ElementsNamesCodes.TryGetValue(name, out code))
				{
					good = AppContext.Repository.GetDictionaryItem(GoodsDictName, code);
				}
				// ищем товар по штрих-кодам
				if (good == null)
				{
					foreach (var barcode in barcodes)
					{
						int barcodeCode;
						if (dictData.BarcodesCodes.TryGetValue(barcode, out barcodeCode))
						{
							var barcodeObj = AppContext.Repository.GetDictionaryItem(BarcodesDictName, barcodeCode);
							good = (DictionaryObject)barcodeObj["Owner"];
							break;
						}
					}
				}
				// до сих пор не нашли
				if (good == null)
				{
					good = AppContext.Repository.CreateDictionaryItem(GoodsDictName);
					code = good.Code;
				}
				good.Name = name;
				dictData.ElementsNamesCodes[name] = good.Code;

				if (unit > 0)
					good["Единица измерения"] = unit;
				if (parent != null)
					good.Parent = parent;
				// пробуем дополнительные поля
				foreach (var idxField in otherIdxsFields)
				{
					var value = GetValueAsString(row, idxField.Item1);
					if (value.Length > 0)
						good[idxField.Item2] = value;
				}
				good.IsDeleted = false;
				AppContext.Repository.SaveChanges(good);

				CreateBarcodes(good.Code, barcodes, dictData.BarcodesCodes);

				var qnt = DataConverter.ToDecimal(GetValueAsString(row, quantityColIdx));
				var inPrice = DataConverter.ToDecimal(GetValueAsString(row, priceInColIdx));
				if (qnt > 0)
				{
					income.Tables[0].Add();
					income.Tables[0]["Товар"] = good.Code;
					income.Tables[0]["Количество"] = qnt;
					income.Tables[0]["Цена"] = inPrice;
					income.Tables[0]["Сумма"] = qnt * inPrice;

					income.Amount += (decimal)income.Tables[0]["Сумма"];
				}
				var outPrice = DataConverter.ToDecimal(GetValueAsString(row, priceOutColIdx));
				if (outPrice > 0)
				{
					pricing.Tables[0].Add();
					pricing.Tables[0]["Товар"] = good.Code;
					pricing.Tables[0]["Цена закупки"] = inPrice;
					pricing.Tables[0]["Цена продажи"] = outPrice;
					pricing.Tables[0]["Процент наценки"] = inPrice != 0 ? (outPrice - inPrice) / inPrice * 100m : 100m;
				}
				count++;
				Context.WriteStatus($"Обработано {count} товаров");
			}
			if (income.Tables[0].Count > 0)
			{
				var idxs = income.Tables[0].SumBy(new[] { "Товар" }, new[] { "Количество", "Сумма" });
				foreach (var i in idxs)
				{
					income.Tables[0].SelectedIndex = i;
					var qnt = (decimal)income.Tables[0]["Количество"];
					if (qnt > 0)
						income.Tables[0]["Цена"] = (decimal)income.Tables[0]["Сумма"] / qnt;
				}
				AppContext.Repository.SaveChanges(income);
				Context.Console.Write("Создан " + income);
				AppContext.Repository.ProcessDocumentTo(income, DocumentStatus.Registered);
			}
			if (pricing.Tables[0].Count > 0)
			{
				pricing.Tables[0].SumBy(new[] { "Товар" }, new string[0]);
				AppContext.Repository.SaveChanges(pricing);
				Context.Console.Write("Создан " + pricing);
				AppContext.Repository.ProcessDocumentTo(pricing, DocumentStatus.Registered);
			}
			SetNumerator(GoodsDictName);
		}

		private int GetUnit(string name, Dictionary<string, int> namesCodes)
		{
			if (string.IsNullOrEmpty(name))
				return 0;

			int code;
			if (!namesCodes.TryGetValue(name, out code))
			{
				var obj = AppContext.Repository.CreateDictionaryItem(UnitsDictName);
				obj.Name = name;
				AppContext.Repository.SaveChanges(obj);

				code = obj.Code;
				namesCodes.Add(name, code);
			}
			return code;
		}

		private DictionaryObject GetGroup(string name, int unit, Dictionary<string, int> namesCodes)
		{
			DictionaryObject group = null;
			int code;
			var groupName = name;
			var i = 0;
			while (namesCodes.TryGetValue(groupName, out code))
			{
				group = AppContext.Repository.GetDictionaryItem(GoodsDictName, code);
				if (!group.IsGroup)
				{
					group = null;
					i++;
					groupName = name + " (" + i + ")";
					continue;
				}
				else if (group.IsDeleted)
				{
					group.IsDeleted = false;
					AppContext.Repository.SaveChanges(group);
				}
				else 
				{
					break;
				}
			}

			if (group == null)
			{
				group = AppContext.Repository.CreateDictionaryItem(GoodsDictName);
				group.IsGroup = true;
				group.Name = groupName;
				if (unit > 0)
					group["Единица измерения"] = unit;
				AppContext.Repository.SaveChanges(group);

				namesCodes.Add(groupName, group.Code);
			}

			return group;
		}

		private int CreateSore()
		{
			var criteria = new QueryCriteria("Склады")
				.WhereDictNotDeleted()
				.Select("Code");
			var result = AppContext.Repository.ExecuteQuery(criteria);
			if (result.Read())
			{
				return (int)result["Code"];
			}
			else
			{
				var obj = AppContext.Repository.CreateDictionaryItem("Склады");
				obj.Name = "Основной склад";
				AppContext.Repository.SaveChanges(obj);
				return obj.Code;
			}
		}

		private void CreateBarcodes(int good, IEnumerable<string> barcodes, Dictionary<string, int> barcodesCodes)
		{
			foreach (var barcode in barcodes)
			{
				int code;
				if (!barcodesCodes.TryGetValue(barcode, out code))
				{
					var obj = AppContext.Repository.CreateDictionaryItem(BarcodesDictName);
					obj.Name = barcode;
					obj["Владелец"] = good;
					obj.IsDeleted = false;
					AppContext.Repository.SaveChanges(obj);

					barcodesCodes.Add(barcode, obj.Code);
				}
				else
				{
					var obj = AppContext.Repository.GetDictionaryItem(BarcodesDictName, code);
					if (obj.IsDeleted)
					{
						obj.IsDeleted = false;
						AppContext.Repository.SaveChanges(obj);
					}
				}
			}
		}

		private void ImportContractors(DataTable data)
		{
			const int nameColIdx = 0;
			const int fullNameColIdx = 1;
			const int groupColIdx = 2;
			const int innColIdx = 3;
			const int kppColIdx = 4;
			const int addressColIdx = 5;
			const int legalAddressColIdx = 6;
			const int phoneColIdx = 7;
			const int emailColIdx = 8;
			
			const int maxLenghtInn = 12;

			var dictData = new DictData(AppContext, ContractorsDictName);
			var innsCodes = DictData.GetFieldsCodes(AppContext, Context, ContractorsDictName, "ИНН");
			// проверяем дополнительные поля
			List<Tuple<int, string>> idxsFields = GetOtherIdxsFields(emailColIdx + 1, data, ContractorsDictName);
			// и основные сюда же добавим
			idxsFields.Add(Tuple.Create(fullNameColIdx, "Полное наименование"));
			idxsFields.Add(Tuple.Create(kppColIdx, "КПП"));
			idxsFields.Add(Tuple.Create(addressColIdx, "Адрес"));
			idxsFields.Add(Tuple.Create(legalAddressColIdx, "Юридический адрес"));
			idxsFields.Add(Tuple.Create(phoneColIdx, "Телефон"));
			idxsFields.Add(Tuple.Create(emailColIdx, "Email"));

			var count = 0;
			foreach (var row in data.AsEnumerable().Where(r => r[nameColIdx] != DBNull.Value))
			{
				var name = GetValueAsString(row, nameColIdx);
				if (name.Length == 0)
					continue;

				var inn = GetValueAsString(row, innColIdx);
				if (inn.Length > maxLenghtInn)
				{
					Context.Console.Write($"Длина ИНН больше {maxLenghtInn} символов ({inn}), строка пропущена.");
					continue;
				}
				DictionaryObject parent = null;
				var groupName = GetValueAsString(row, groupColIdx);
				if (groupName.Length > 0)
				{
					parent = GetContractorsGroup(groupName, dictData.GroupsNamesCodes);
				}

				DictionaryObject contractor = null;
				int code;
				// ищем контрагента по ИНН
				if (inn.Length > 0 && innsCodes.TryGetValue(inn, out code))
				{
					contractor = AppContext.Repository.GetDictionaryItem(ContractorsDictName, code);
				}
				// ищем по наименованию
				if (contractor == null && dictData.ElementsNamesCodes.TryGetValue(name, out code))
				{
					contractor = AppContext.Repository.GetDictionaryItem(ContractorsDictName, code);
				}
				// до сих пор не нашли
				if (contractor == null)
				{
					contractor = AppContext.Repository.CreateDictionaryItem(ContractorsDictName);
				}
				contractor.Name = name;
				dictData.ElementsNamesCodes[name] = contractor.Code;

				if (inn.Length > 0)
					contractor["ИНН"] = inn;
				if (parent != null)
					contractor.Parent = parent;

				// оставшиеся основные и дополнительные поля
				foreach (var idxField in idxsFields)
				{
					var value = GetValueAsString(row, idxField.Item1);
					if (value.Length > 0)
						contractor[idxField.Item2] = value;
				}
				contractor.IsDeleted = false;
				AppContext.Repository.SaveChanges(contractor);

				count++;
				Context.WriteStatus($"Обработано {count} контрагентов");
			}
			SetNumerator(ContractorsDictName);
		}

		private DictionaryObject GetContractorsGroup(string name, Dictionary<string, int> namesCodes)
		{
			DictionaryObject group;
			int code;
			if (namesCodes.TryGetValue(name, out code))
			{
				group = AppContext.Repository.GetDictionaryItem(ContractorsDictName, code);
				group.IsDeleted = false;
			}
			else
			{
				group = AppContext.Repository.CreateDictionaryItem(ContractorsDictName);
				group.IsGroup = true;
				group.Name = name;

				namesCodes.Add(name, group.Code);
			}
			AppContext.Repository.SaveChanges(group);

			return group;
		}

		private List<Tuple<int, string>> GetOtherIdxsFields(int startIdx, DataTable data, string dictName)
		{
			var otherIdxsFields = new List<Tuple<int, string>>();
			var contrsMeta = AppContext.Metadata.GetDictionary(dictName);
			for (int i = startIdx; i < data.Columns.Count; i++)
			{
				var field = data.Columns[i].ColumnName.Trim();
				if (field.Length > 0 && contrsMeta.GetFieldByName(field) != null)
				{
					otherIdxsFields.Add(Tuple.Create(i, field));
				}
			}

			return otherIdxsFields;
		}

		private bool NotExistsFile(string fileName)
		{
			bool result = !File.Exists(fileName);
			if (result)
				Context.Alert("Указанный файл не существует.");

			return result;

		}

		private DataTable GetDataFromFile(string fileName)
		{
			DataTable data;
			try
			{
				data = Utils.ParseExcelData(File.ReadAllBytes(fileName));
			}
			catch (Exception ex)
			{
				WriteErrorToLog(ex);
				Context.Alert("Не удалось получить данные из файла, возможно он заблокирован другой программой или имеет неверный формат.");
				return null;
			}
			if (data == null)
				Context.Alert("Не удалось получить данные из файла.");

			return data;
		}

		private static string GetValueAsString(DataRow row, int column)
		{
			var result = (row.Table.Columns.Count <= column || row[column] == null || row[column] == DBNull.Value) ? "" : row[column].ToString();
			return result
				.Replace("\t", " ")
				.Replace("\n", " ")
				.Replace("\r", " ")
				.Trim();
		}

		private void SetNumerator(string dictName)
		{
			var criteria = new QueryCriteria(dictName).Max("Code", "Code");
			var maxCode = ExecuteQuery(criteria).AsEnumerable().Select(r => (int)r["Code"]).FirstOrDefault();
			if (maxCode > 0)
			{
				var metadata = AppContext.Metadata.GetDictionary(dictName);
				AppContext.Numerator.Set(metadata.TableName, maxCode);
			}
		}

		[ServiceMethod]
		public void RunCSV(string fileName, string columnSeparator, int nameColumn, int groupColumn, int unitColumn,
			int quantityColumn, int incomePriceColumn, int outcomePriceColumn, bool multiRestsColumns)
		{
			if (NotExistsFile(fileName))
				return;

			var nameColumnIdx = nameColumn - 1;
			var groupColumnIdx = groupColumn - 1;
			var unitColumnIdx = unitColumn - 1;
			var quantityColumnIdx = quantityColumn - 1;
			var incomePriceColumnIdx = incomePriceColumn - 1;
			var outcomePriceColumnIdx = outcomePriceColumn - 1;

			if (nameColumnIdx < 0)
			{
				Context.Cancel("Не указана колонка для наименования.");
				return;
			}
			var csvSeparator = string.IsNullOrEmpty(columnSeparator) ? "\t" : columnSeparator;

			var lines = File.ReadAllLines(fileName);
			if (lines.Length <= 0)
			{
				Context.Cancel("Файл не содержит строк.");
				return;
			}
			var rows = new List<KDataRow>();
			foreach (var line in lines)
			{
				var columns = line.Split(csvSeparator.Select(c => c).ToArray());
				var index = 0;
				var row = new KDataRow(columns.Length);
				foreach (var column in columns)
				{
					row[index.ToString()] = column;
					index++;
				}
				rows.Add(row);
			}
			var dictData = new DictData(AppContext, GoodsDictName)
			{
				UnitsNamesCodes = DictData.GetFieldsCodes(AppContext, Context, UnitsDictName, "Name"),
				BarcodesCodes = DictData.GetFieldsCodes(AppContext, Context, BarcodesDictName, "Name")
			};

			var quantityColsCount = (multiRestsColumns && quantityColumnIdx >= 0) ? (rows[0].GetFields().Count() - quantityColumnIdx) : 1;
			var incomes = new List<DocumentObject>(quantityColsCount);
			for (int i = 0; i < quantityColsCount; i++)
			{
				var income = AppContext.Repository.CreateDocument("Приход товаров");
				var pref = "ПрТ-";
				income.Number = pref + AppContext.Numerator.Next(pref);
				const int izlishki = 2;
				income["Операция"] = izlishki;
				income["Комментарий"] = (i + 1) + "-ая колонка с остатком";
				incomes.Add(income); 
			}
			var pricing = AppContext.Repository.CreateDocument("Ценообразование");
			var prefix = "Цен-";
			pricing.Number = prefix + AppContext.Numerator.Next(prefix);

			var count = 0;
			foreach (var row in rows)
			{
				var name = row[nameColumnIdx.ToString()] as string;
				if (string.IsNullOrEmpty(name))
					continue;

				var unit = unitColumnIdx >= 0
					? GetUnit(row[unitColumnIdx.ToString()].ToString(), dictData.UnitsNamesCodes)
					: GetUnit("шт", dictData.UnitsNamesCodes);

				DictionaryObject parent = null;
				var groupName = groupColumnIdx >= 0 ? row[groupColumnIdx.ToString()] as string : "";
				if (!string.IsNullOrEmpty(groupName))
				{
					parent = GetGroup(groupName, unit, dictData.GroupsNamesCodes);
				}
				DictionaryObject good = null;
				int code;
				if (dictData.ElementsNamesCodes.TryGetValue(name, out code))
				{
					good = AppContext.Repository.GetDictionaryItem(GoodsDictName, code);
				}
				else
				{
					good = AppContext.Repository.CreateDictionaryItem(GoodsDictName);
					good.Name = name;
				}
				if (unit > 0)
					good["Единица измерения"] = unit;
				if (parent != null)
					good.Parent = parent;

				AppContext.Repository.SaveChanges(good);

				var inPrice = incomePriceColumnIdx >= 0 ? DataConverter.ToDecimal(row[incomePriceColumnIdx.ToString()].ToString().Replace(",", "."), -1) : -1;
				inPrice = Math.Max(inPrice, 0);
				if (quantityColumnIdx >= 0)
				{
					for (int i = 0; i < incomes.Count; i++)
					{
						var fieldName = (quantityColumnIdx + i).ToString();
						var qnt = DataConverter.ToDecimal(row[fieldName].ToString().Replace(",", "."), -1);
						if (qnt > 0)
						{
							var income = incomes[i];
							income.Tables[0].Add();
							income.Tables[0]["Товар"] = good.Code;
							income.Tables[0]["Количество"] = qnt;
							income.Tables[0]["Цена"] = inPrice;
							income.Tables[0]["Сумма"] = qnt * inPrice;

							income.Amount += (decimal)income.Tables[0]["Сумма"];
						}
					}
				}
				decimal outPrice = outcomePriceColumnIdx >= 0 ? DataConverter.ToDecimal(row[outcomePriceColumnIdx.ToString()].ToString().Replace(",", "."), -1) : -1;
				if (outPrice > 0)
				{
					pricing.Tables[0].Add();
					pricing.Tables[0]["Товар"] = good.Code;
					pricing.Tables[0]["Цена закупки"] = inPrice;
					pricing.Tables[0]["Цена продажи"] = outPrice;
					pricing.Tables[0]["Процент наценки"] = inPrice != 0 ? (outPrice - inPrice) / inPrice * 100m : 100m;
				}
				count++;
				Context.WriteStatus($"Обработано {count} товаров");
			}
			foreach (var income in incomes)
			{
				if (income.Tables[0].Count > 0)
				{
					AppContext.Repository.SaveChanges(income);
					Context.Console.Write("Создан " + income);
				}
			}
			if (pricing.Tables[0].Count > 0)
			{
				AppContext.Repository.SaveChanges(pricing);
				Context.Console.Write("Создан " + pricing);
			}
			SetNumerator(GoodsDictName);

			Context.Alert("Выполнено.");
		}
	}
}
