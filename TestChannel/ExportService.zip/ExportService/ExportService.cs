﻿using Kayala.Objects;
using Kayala.Query;
using Kayala.Services;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ExportService
{
	[Service]
	public class ExportService : BaseService
	{
		private const string DictName = "Товары";
		private const string NameField = "Наименование";
		private const string CodeField = "Код";
		private const string RestField = "Остаток";
		private const string BarcodeField = "Штрих-коды";
		private const string PriceInField = "Цена закупки";
		private const string PriceOutField = "Цена продажи";
		private const string GroupField = "Группа";
		private const string FreePriceField = "Свободная цена";
		private const string DeleteField = "ПометкаНаУдаление";

		[ServiceMethod]
		public void Run(IEnumerable<string> lines, bool withDeleted, IEnumerable<int> goods, IEnumerable<int> stores)
		{
			List<string> fields = lines.ToList();

			var criteria = (goods?.Any() == true
				? QueryHelper.GetAllCodes(AppContext, DictName, goods)
				: new QueryCriteria(DictName).Select("Code"))
				.WhereDictIsNotGroup();
			if (!withDeleted)
				criteria.WhereDictNotDeleted();
			var query = ExecuteQuery(criteria);

			var codes = (goods?.Any() == true) ? query.AsEnumerable().Select(r => (int)r["Code"]).ToList() : null;
			var pricesSvc = AppContext.Services.GetService<IPrices>();
			var salePrices = fields.Contains(PriceOutField) ? pricesSvc.GetSalePrices(null, codes, null) : null;
			var incomePrices = fields.Contains(PriceInField) ? pricesSvc.GetIncomePrices(null, codes) : null;
			var goodsRests = fields.Contains(RestField) ? GetGoodsRests(goods, stores) : null;

			criteria = new QueryCriteria("Штрихкоды")
				.Select("Owner").Select("Name")
				.WhereDictNotDeleted();
			var barcodes = ExecuteQuery(criteria).AsEnumerable()
				.Select(r => new { Good = (int)r["Owner"], Barcode = (string)r["Name"] }).ToList();

			var rep = CreateReport("Export.tcr");

			for (int i = 0; i < fields.Count; i++)
			{
				string section = "ТабСтрока20";
				string field = fields[i];
				switch (field)
				{
					case NameField:
					case BarcodeField:
						section = "ТабСтрока50";
						break;
					case CodeField:
						section = "ТабЦелое";
						break;
					case RestField:
						section = "ТабОстаток";
						break;
					case PriceInField:
					case PriceOutField:
						section = "ТабЦена";
						break;
				}

				AddJoinSection(rep, section, i == 0);
				rep.SetParameter("Наим", field);
			}

			query = query.BuildTree(new[] { new TreeGroup("Code", fields.Any(f => f.StartsWith(GroupField))) }, new string[0]);
			int count = 0;
			query.ProcessLevels((row, level, group) =>
			{
				if (group == null)
					return;

				var good = (DictionaryObject)row[group.FieldName];
				if (good.IsGroup)
					return;

				for (int i = 0; i < fields.Count; i++)
				{
					string field = fields[i];
					switch (field)
					{
						case NameField:
						case BarcodeField:
							var name = good.Name;
							if (field == BarcodeField)
								name = string.Join(", ", barcodes.Where(b => b.Good == good.Code).Select(b => b.Barcode));

							AddJoinSection(rep, "Строка50", i == 0);
							rep.SetParameter("Наим", name);
							rep.SetParameter("Type", DictName);
							rep.SetParameter("Code", good.Code);
							break;
						case CodeField:
							AddJoinSection(rep, "Целое", i == 0);
							rep.SetParameter("Целое", good.Code);
							break;
						case RestField:
							decimal rest;
							goodsRests.TryGetValue(good.Code, out rest);
							AddJoinSection(rep, "Остаток", i == 0);
							rep.SetParameter("Кол", rest);
							break;
						case PriceInField:
						case PriceOutField:
							decimal price;
							(field == PriceOutField ? salePrices : incomePrices).TryGetValue(good.Code, out price);
							AddJoinSection(rep, "Цена", i == 0);
							rep.SetParameter("Цена", price);
							break;
						case FreePriceField:
						case DeleteField:
							AddJoinSection(rep, "Строка20", i == 0);
							rep.SetParameter("Наим", (bool)good[field] ? "Да" : "");
							break;
						case GroupField + "1":
						case GroupField + "2":
						case GroupField + "3":
							AddJoinSection(rep, "Строка20", i == 0);
							var groupNo = int.Parse(field.Remove(0, GroupField.Length));
							var parentNo = good.Level - groupNo + 1;
							if (parentNo > 0)
								rep.SetParameter("Наим", good[$"Parent{parentNo}"].ToString());
							break;
						default:
							AddJoinSection(rep, "Строка20", i == 0);
							rep.SetParameter("Наим", good[field].ToString());
							break;
					}
				}
				count++;
			});
		}

		private void AddJoinSection(CellReport.ReportDocument rep, string section, bool add)
		{
			if (add)
				rep.AddSection(section);
			else
				rep.JoinSection(section);
		}

		private Dictionary<int, decimal> GetGoodsRests(IEnumerable<int> goods, IEnumerable<int> stores)
		{
			var criteria = CreateRestQuery("Остатки товаров")
				.Select("Товар")
				.Sum("Количество")
				.OnDate(AppContext.NowDateTime);
			if (goods?.Any() == true)
				criteria.WhereIn("Товар", QueryHelper.GetAllCodes(AppContext, DictName, goods));
			if (stores?.Any() == true)
				criteria.WhereIn("Склад", QueryHelper.GetAllCodes(AppContext, "Склады", stores));

			return ExecuteQuery(criteria).AsEnumerable().ToDictionary(r => (int)r["Товар"], r => (decimal)r["Количество"]);
		}
	}

	public interface IPrices
	{
		Dictionary<int, decimal> GetSalePrices(DateTime? date, IEnumerable<int> goods, int? pricesType);
		Dictionary<int, decimal> GetIncomePrices(DateTime? date, IEnumerable<int> goods);
	}
}
