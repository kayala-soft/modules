﻿using Kayala.Services;
using System;
using System.Collections.Generic;

namespace PricingOldPrice
{
	[Service("Ценообразование" + "GoodsMarkups")]
	public class PricingGoodsMarkups : BaseService
	{
		[ServiceMethod]
		public bool CalcFromMarkup()  // Цена продажи зафиксирована, пересчитывать от нее Процен наценки
		{
			return false;
		}

		[ServiceMethod]
		public List<Tuple<int, decimal>> GetGoodsMarkups(IEnumerable<int> goods, int pricesType)
		{
			return new List<Tuple<int, decimal>>();
		}
	}
}
