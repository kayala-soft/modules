﻿using Kayala;
using Kayala.Objects;
using Kayala.Query;
using Kayala.Services;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ContractorGoods
{
	[Service(DictName)]
	public class ContractorGoodsDict : BaseService
	{
		public const string DictName = "Товары контрагента";

		[ServiceMethod]
		public void BeforeSave(MethodContext context)
		{
			var obj = context.DictObject;
			var good = (DictionaryObject)obj["Товар"];

			var criteria = new QueryCriteria(DictName)
				.WhereDictOwnerIs((int)obj["Owner"])
				.Where("[Товар] = @good", good.Code)
				.Where("Code <> @code", obj.Code);
			if (ExecuteQuery(criteria).Count > 0)
			{
				context.Cancel($"Товар '{good.Name}' ({good.Code}) уже добавлен (возможно помечен на удаление).");
			}
		}

		internal static Dictionary<int, decimal> GetSalePrices(int contractor, IEnumerable<int> goods, KAppContext appContext)
		{
			var criteria = new QueryCriteria(DictName)
				.Select("Товар").Select("Цена продажи")
				.WhereDictOwnerIs(contractor)
				.WhereIn("Товар", goods)
				.Where("[Цена продажи] > 0")
				.WhereDictNotDeleted();
			var query = appContext.Repository.ExecuteQuery(criteria);

			var result = new Dictionary<int, decimal>();
			while (query.Read())
				result[(int)query["Товар"]] = (decimal)query["Цена продажи"];

			return result;
		}
	}

	[Service("Расход товаров" + "Prices")]
	public class OutcomeGoodsDocPrices : BaseService
	{
		[ServiceMethod]
		public List<Tuple<int, decimal>> GetPrices(DocumentObject doc, IEnumerable<int> goods)
		{
			if ((int)doc["Операция"] == 6 /* Списание */)
			{
				return new List<Tuple<int, decimal>>(0);
			}
			Dictionary<int, decimal> goodsPrices;
			var svc = AppContext.Services.GetService<IPrices>();
			var isSale = new[] { 4 /* Розничная продажа */, 5 /* Оптовая продажа */ }.Contains((int)doc["Операция"]);
			if (isSale)
			{
				var contractor = (int)doc["Контрагент"];
				if (contractor > 0)
				{
					goodsPrices = ContractorGoodsDict.GetSalePrices(contractor, goods, AppContext);
					var codes = goods.Except(goodsPrices.Keys).ToList();
					if (codes.Count > 0)
					{
						var prices = svc.GetSalePrices(null, codes, (int)doc["Тип цен"]);
						goodsPrices = goodsPrices.Union(prices).ToDictionary(p => p.Key, p => p.Value);
					}
				}
				else
				{
					goodsPrices = svc.GetSalePrices(null, goods, (int)doc["Тип цен"]);
				}
			}
			else
			{
				goodsPrices = svc.GetIncomePrices(null, goods);
			}
			return goodsPrices.Select(p => Tuple.Create(p.Key, p.Value)).ToList();
		}
	}

	[Service("РМК" + "Prices")]
	public class CashiersWorkplacePrices : BaseService
	{
		[ServiceMethod]
		public decimal GetPrice(int good, DictionaryObject client, DictionaryObject discount)
		{
			var prices = GetPrices(new[] { good }, client, discount);
			return prices.Count > 0 ? prices[0].Item2 : 0m;
		}

		[ServiceMethod]
		public List<Tuple<int, decimal>> GetPrices(IEnumerable<int> goods, DictionaryObject client, DictionaryObject discount)
		{
			if (goods?.Any() == false)
			{
				return new List<Tuple<int, decimal>>(0);
			}
			Dictionary<int, decimal> goodsPrices;
			var svc = AppContext.Services.GetService<IPrices>();
			if (client != null)
			{
				goodsPrices = ContractorGoodsDict.GetSalePrices(client.Code, goods, AppContext);
				var codes = goods.Except(goodsPrices.Keys).ToList();
				if (codes.Count > 0)
				{
					var prices = svc.GetSalePrices(null, codes, (int)(discount?["Тип цен"] ?? 0));
					goodsPrices = goodsPrices.Union(prices).ToDictionary(p => p.Key, p => p.Value);
				}
			}
			else
			{
				goodsPrices = svc.GetSalePrices(null, goods, (int)(discount?["Тип цен"] ?? 0));
			}
			return goodsPrices.Select(p => Tuple.Create(p.Key, p.Value)).ToList();
		}
	}

	public interface IPrices
	{
		decimal GetPrevSalePrice(int code);
		Dictionary<int, decimal> GetSalePrices(DateTime? date, IEnumerable<int> goods, int? pricesType);
		decimal GetSalePrice(DateTime? date, int good, int? pricesType);

		Dictionary<int, decimal> GetIncomePrices(DateTime? date, IEnumerable<int> goods);
		decimal GetIncomePrice(DateTime? date, int good);
	}
}
