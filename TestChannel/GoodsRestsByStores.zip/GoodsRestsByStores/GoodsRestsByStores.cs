﻿using CellReport;
using Kayala.Core;
using Kayala.Metadata.Fields;
using Kayala.Objects;
using Kayala.Query;
using Kayala.Services;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace GoodsRestsByStores
{
	[Service]
    public class GoodsRestsByStoresRep : BaseService
	{
		[ServiceMethod]
		public void Load(out IEnumerable<string> allStores, out IEnumerable<string> stores)
		{
			var criteria = new QueryCriteria("Склады")
				.Select("Name")
				.WhereDictNotDeleted()
				.WhereDictIsNotGroup();
			allStores = ExecuteQuery(criteria).AsEnumerable().Select(r => (string)r["Name"]).ToList();
			stores = allStores.ToList();
		}

		[ServiceMethod]
		[Param("Date", FieldTypeId.DateTime, Default = DateForGenerate.EndOfToday)]
		[Param("ShowGoods", FieldTypeId.Boolean)]
		[Param("ShowGoodGroups", FieldTypeId.Boolean)]
		[Param("GroupsCount", FieldTypeId.Int32, Default = 1)]
		[Param("ShowAmount", FieldTypeId.Boolean)]
		[Param("Stores", FieldTypeId.SystemObject)]
		[Param("Goods", FieldTypeId.LinksToDictionaries, ObjectName = "Товары")]
		//public void Run(DateTime date, bool showGoods, bool showGoodGroups, int groupsCount, IEnumerable<string> stores, [ObjectName("Товары")]IEnumerable<int> goods)
		public void Run(MethodContext context)
		{
			var stores = (IEnumerable<string>)context["Stores"].GetValue();
			if (stores?.Any() != true)
				Load(out stores, out stores);

			if (stores?.Any() != true)
			{
				Context.Cancel("Необходимо отметить склады для вывода.");
				return;
			}
			var date = (DateTime)context["Date"];
			var showGoods = (bool)context["ShowGoods"];
			var showGoodGroups = (bool)context["ShowGoodGroups"];
			var groupsCount = (int)context["GroupsCount"];
			var showAmount = (bool)context["ShowAmount"];
			var goods = (IEnumerable<int>)context["Goods"].GetValue();
			
			var groups = new List<TreeGroup>();
			Context.WriteStatus("Выполнение запроса ...");

			var criteria = new QueryCriteria("Склады")
				.Select("Code").Select("Name")
				.WhereIn("Name", stores)
				.OrderBy("Name");
			var storesNames = ExecuteQuery(criteria).AsEnumerable()
				.ToDictionary(r => (int)r["Code"], r => (string)r["Name"]);

			var template = CreateRestQuery("Остатки товаров")
				.Sum("Количество").Sum("Сумма")
				.WhereIn("Склад", QueryHelper.GetAllCodes(AppContext, "Склады", storesNames.Keys))
				.OnDate(date);
			if (showGoods || showGoodGroups)
			{
				template.Select("Товар");
				groups.Add(showGoods
					? new TreeGroup("Товар", showGoodGroups)
					: new TreeGroup("Товар", null, true, true, true, groupsCount - 1));
			}
			template.Select("Склад");
			if (goods != null && goods.Any())
				template.WhereIn("Товар", QueryHelper.GetAllCodes(AppContext, "Товары", goods));

			var query = ExecuteQuery(template);

			Context.WriteStatus("Обработка запроса ...");

			storesNames = new Dictionary<int, string> { { 0, "Всего" } }.Union(storesNames).ToDictionary(p => p.Key, p => p.Value);
			var sums = new List<Field>();
			foreach (var code in storesNames.Keys)
			{
				sums.Add(new DecimalField("Qnt_" + code, "Qnt_" + code, 15, 3));
				sums.Add(new DecimalField("Amount_" + code, "Amount_" + code, 15, 2));
			}
			var fields = sums.Union(groups.Select(g => new DictionaryField(g.FieldName, g.FieldName, "Товары", AppContext.Name))).ToList();

			var result = new QueryResult(AppContext.Name, new List<KDataRow>(), fields, null);
			while (query.Read())
			{
				var qnt = (decimal)query["Количество"];
				var codeStore = (int)query["Склад"];

				result.AddRow();
				if (groups.Count > 0)
					result["Товар"] = query["Товар"];
				result["Qnt_0"] = qnt;
				result["Amount_0"] = query["Сумма"];
				result["Qnt_" + codeStore] = qnt;
				result["Amount_" + codeStore] = query["Сумма"];
			}
			Context.WriteStatus("Построение дерева отчета ...");

			query = result.BuildTree(groups.ToArray(), sums.Select(s => s.FieldName).ToArray());

			Context.WriteStatus("Вывод печатной формы ...");
			var rep = CreateReport("ОстаткиПоСкладам.tcrp");
			rep.AddSection("Шапка");
			rep.SetParameter("Период", "на: " + date);
			if (goods != null && goods.Any())
				rep.SetParameter("Товары", "По товарам: " + QueryHelper.GetDictNames(AppContext, "Товары", goods));
			rep.AddSection("Таблица");
			var colName = showGoodGroups ? "Группа товаров" : "";
			rep.SetParameter("Наименование", colName + (showGoods ? (colName.Any() ? " / " : "") + "Товар" : ""));

			var col = 12;
			foreach (var pair in storesNames)
			{
				rep.JoinSection("ТаблицаКол");
				rep.SetParameter("Склад", pair.Value);
				if (showAmount)
				{
					const int row = 4;
					rep.JoinSection("ТаблицаСум");
					rep.Manager.GetCell(row, col).Span = new CellReport.Core.CellSpan { ColSpan = 2 };
					col += 3;
				}
			}
			query.ProcessLevels((row, level, group) =>
			{
				if (group == null)
					return;

				var good = (DictionaryObject)row["Товар"];

				rep.AddSection(level.ToString(CultureInfo.InvariantCulture));
				rep.SetParameter("Type", "Товары");
				rep.SetParameter("Code", good.Code);
				rep.SetParameter("Наим", good.Name);
				rep.SetParameter("Код", good.Code);
				rep.SetParameter("Единица", (string)good["Единица измерения"]);
				foreach (var code in storesNames.Keys)
					JoinValues(rep, "", (decimal)row["Qnt_" + code], (decimal)row["Amount_" + code], showAmount);
			});
			query.ToBegin();
			query.Read();
			rep.AddSection("Подвал");
			foreach (var code in storesNames.Keys)
				JoinValues(rep, "Подвал", (decimal)query["Qnt_" + code], (decimal)query["Amount_" + code], showAmount);
		}

		private static void JoinValues(ReportDocument rep, string section, decimal qnt, decimal amount, bool showAmount)
		{
			rep.JoinSection(section + "Кол");
			rep.SetParameter("Кол", qnt);
			if (showAmount)
			{
				rep.JoinSection(section + "Сум");
				rep.SetParameter("Цена", qnt != 0 ? amount / qnt : 0m);
				rep.SetParameter("Сум", amount);
			}
		}

	}
}
