﻿using CellReport;
using Kayala.Core;
using Kayala.Metadata.Fields;
using Kayala.Query;
using Kayala.Services;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;

namespace Advisor
{
	[Service("Продажи по рекомендателям")]
	public class SalesByAdvisorsRep : BaseService
    {
		[ServiceMethod]
		[Param("Start", FieldTypeId.DateTime, Default = DateForGenerate.CurrentMonth)]
		[Param("End", FieldTypeId.DateTime, Default = DateForGenerate.EndOfToday)]
		[Param("LinesList", FieldTypeId.SystemObject)]
		[Param("Lines", FieldTypeId.SystemObject)]
		[Param("ShowGoodGroups", FieldTypeId.Boolean, Default = false)]
		[Param("GroupsCount", FieldTypeId.Int32, Default = 1)]
		[Param("Contractors", FieldTypeId.LinksToDictionaries, ObjectName = "Контрагенты")]
		[Param("Goods", FieldTypeId.LinksToDictionaries, ObjectName = "Товары")]
		[Param("Subdivs", FieldTypeId.LinksToDictionaries, ObjectName = "Склады")]
		public void Run(MethodContext context)
		{
			var start = (DateTime)context["Start"];
			var end = (DateTime)context["End"];
			var lines = (IEnumerable<string>)context["Lines"].GetValue();
			var showGoodGroups = (bool)context["ShowGoodGroups"];
			var contractors = (IEnumerable<int>)context["Contractors"].GetValue();
			var goods = (IEnumerable<int>)context["Goods"].GetValue();
			var subdivs = (IEnumerable<int>)context["Subdivs"].GetValue();

			var groupFields = new List<TreeGroup>();
			foreach (var line in (IEnumerable<string>)context["LinesList"].GetValue())
			{
				switch (line)
				{
					case "Рекомендатели":
						if (lines.Contains(line))
							groupFields.Add(new TreeGroup("Рекомендатель", false));
						break;
					case "Склады":
						if (lines.Contains(line))
							groupFields.Add(new TreeGroup("Склад", false));
						break;
					case "Товары":
						if (lines.Contains(line))
							groupFields.Add(new TreeGroup("Товар", showGoodGroups));
						else if (showGoodGroups)
							groupFields.Add(new TreeGroup("Товар", null, true, true, true, (int)context["GroupsCount"] - 1));
						break;
					case "Документы":
						if (lines.Contains(line))
							groupFields.Add(new TreeGroup("Документ", false));
						break;
				}
			}
			var criteria = new QueryCriteria("Остатки товаров")
				.InnerJoin("Расход товаров", "Документ", "Код")
				.Sum("Количество")
				.Sum("Сумма")
				.Sum("Сумма продажи")
				.Where("[ДатаВремя] between @start and @end", start, end)
				.WhereIn("Операция", new[] { 4, 5, 10, 11 }) // продажи и возвраты
				.Where("[Расход товаров.Рекомендатель] is not null");
			foreach (var field in groupFields.Select(g => g.FieldName))
			{
				var selectField = field == "Рекомендатель" ? "Расход товаров.Рекомендатель" : field;
				criteria.Select(selectField).GroupBy(selectField);
			}
			if (contractors != null && contractors.Any())
				criteria.WhereIn("Расход товаров.Рекомендатель", QueryHelper.GetAllCodes(AppContext, "Контрагенты", contractors));
			if (goods != null && goods.Any())
				criteria.WhereIn("Товар", QueryHelper.GetAllCodes(AppContext, "Товары", goods));
			if (subdivs != null && subdivs.Any())
				criteria.WhereIn("Склад", QueryHelper.GetAllCodes(AppContext, "Склады", subdivs));

			var query = ExecuteQuery(criteria);
			if (groupFields.Count > 0)
				query = query.BuildTree(groupFields.ToArray(), new[] { "Количество", "Сумма", "Сумма продажи" });

			var rep = CreateReport("ПродажиПоРекомендателям.tcrp");
			rep.AddSection("Шапка");
			rep.SetParameter("Период", $"за период: c {start} по {end}");
			if (contractors != null && contractors.Any())
				rep.SetParameter("Рекомендатели", "По рекомендателям: " + QueryHelper.GetDictNames(AppContext, "Контрагенты", contractors));
			if (subdivs != null && subdivs.Any())
				rep.SetParameter("Склады", "По складам: " + QueryHelper.GetDictNames(AppContext, "Склады", subdivs));
			if (goods != null && goods.Any())
				rep.SetParameter("Товары", "По товарам: " + QueryHelper.GetDictNames(AppContext, "Товары", goods));
			rep.AddSection("Таблица");

			query.ProcessLevels((r, level, group) =>
			{
				if (group == null)
					return;

				var isDoc = group.FieldName == "Документ";
				var property = r[group.FieldName];
				if (isDoc && property.IsNull()) // пустая/незначащая строка
					return;

				rep.AddSection(level.ToString(CultureInfo.InvariantCulture));
				var typeName = property.Field.TypeId == FieldTypeId.LinkToDictionary ? ((DictionaryField)property.Field).DictionaryName : "Документ";
				rep.SetParameter("Type", typeName);
				rep.SetParameter("Code", isDoc ? (Guid)property : (object)(int)property);
				var comment = (isDoc && !string.IsNullOrEmpty((string)property["Комментарий"]) ? Environment.NewLine + property["Комментарий"] : "");
				rep.SetParameter("Наим", property + comment);
				rep.SetParameter("Код", !isDoc ? (decimal)property : 0m);
				rep.SetParameter("Единица", typeName == "Товары" ? (string)property["Единица измерения"] : "");
				if (level == 0 && groupFields.Count > 1)
					rep.SetParameter("FontStyle", "Bold");
				else if (isDoc)
					rep.SetParameter("FontStyle", "Italic");

				SetRepValues(rep, r);
			});
			query.ToBegin();
			query.Read(); // возвращаемся к первой строке с итогами
			rep.AddSection("Подвал");
			SetRepValues(rep, query);
		}

		private static void SetRepValues(ReportDocument rep, QueryResult row)
		{
			var qnt = -(decimal)row["Количество"]; // т.к. расход отрицательный
			var amount = -(decimal)row["Сумма"];
			var saleAmount = (decimal)row["Сумма продажи"];

			rep.SetParameter("Кол", qnt);
			rep.SetParameter("Цена", qnt != 0 ? amount / qnt : 0m);
			rep.SetParameter("Сум", amount);
			rep.SetParameter("ПродЦена", qnt != 0 ? saleAmount / qnt : 0m);
			rep.SetParameter("ПродСум", saleAmount);
			var profit = saleAmount - amount;
			rep.SetParameter("НацСум", profit);
			rep.SetParameter("НацПроц", amount != 0 ? profit / amount * 100m : 0m);
			if (profit < 0)
				rep.SetParameter("Color", "Red");
		}

	}
}
