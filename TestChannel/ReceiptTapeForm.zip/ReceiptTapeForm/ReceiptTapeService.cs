﻿//using CommonBase; // не загружается dll-ка
using Kayala.Core;
using Kayala.Events;
using Kayala.Objects;
using Kayala.Query;
using Kayala.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ReceiptTapeService
{
	public enum ReceiptTypes
	{
		Sale = 0,
		Return = 1
	}

	public enum PayTypes
	{
		Cash = 0,
		Card = 1
	}

	[Service]
	public class ReceiptTapePrintService : BaseService
	{
		[ServiceMethod]
		public void PrintReceiptTape()
		{
			var doc = Context.DocObject;
			var start = (DateTime)doc["Дата открытия"];

			var rep = CreateReport("ЧековаяЛента.tcr");
			rep.AddSection("Шапка");
			rep.SetSectionObject(doc);
			rep.SetParameter("Автор", AppContext.Users.GetUserByCode(doc.Author)?.Name ?? "");
			rep.AddSection("Таблица");

			var criteria = new QueryCriteria("Продажи")
				.InnerJoin("Чек", "Документ", "Код")
				.Select("Документ").Select("ДатаВремя")
				.Sum("Сумма")
				.Where("[ДатаВремя] between @start and @end", start, doc.DocDateTime)
				.Where("[ККМ] = @pos", (int)doc["ККМ"])
				.Where("[Смена] = @shiftNum", (int)doc["Смена"])
				.GroupBy("Документ").GroupBy("ДатаВремя")
				.OrderBy("ДатаВремя");
			var query = ExecuteQuery(criteria);

			var totals = new decimal[5];
			while (query.Read())
			{
				var receipt = (DocumentObject)query["Документ"];
				var num = Convert.ToInt32(receipt.Number.Remove(0, receipt.Number.LastIndexOf('-') + 1));
				var inverter = (int)receipt["Тип чека"] == (int)ReceiptTypes.Return ? -1m : 1m;
				var pays = GetPays(receipt.Tables[1].CreateIterator());

				var firstRow = true;
				var goods = receipt.Tables[0].CreateIterator();
				while (goods.Read())
				{
					rep.AddSection(firstRow ? "0" : "1");
					rep.SetSectionObject(goods);
					rep.SetParameter("Кол", (decimal)goods["Количество"] * inverter);
					rep.SetParameter("Сум", (decimal)goods["Сумма"] * inverter);
					totals[0] += (decimal)goods["Количество"] * inverter;
					totals[1] += (decimal)goods["Сумма"] * inverter;
					if (firstRow)
					{
						decimal cashSum;
						pays.TryGetValue((int)PayTypes.Cash, out cashSum);
						decimal cardSum;
						pays.TryGetValue((int)PayTypes.Card, out cardSum);

						rep.SetParameter("НомерЧека", num);
						rep.SetParameter("Время", receipt.DocDateTime);
						rep.SetParameter("СуммаЧека", receipt.Amount * inverter);
						rep.SetParameter("Наличные", cashSum * inverter);
						rep.SetParameter("Карта", cardSum * inverter);
						firstRow = false;

						totals[2] += receipt.Amount * inverter;
						totals[3] += cashSum * inverter;
						totals[4] += cardSum * inverter;
					}
				}
			}
			rep.AddSection("Подвал");
			rep.SetSectionObject(doc);
			rep.SetParameter("Кол", totals[0]);
			rep.SetParameter("Сум", totals[1]);
			rep.SetParameter("СуммаЧека", totals[2]);
			rep.SetParameter("Наличные", totals[3]);
			rep.SetParameter("Карта", totals[4]);

			var comments = GetCashInOutComments(start, doc.DocDateTime, (int)doc["ККМ"], (int)doc["Смена"]);
			rep.SetParameter("Внесение", comments[0]);
			rep.SetParameter("Изъятие", comments[1]);
		}

		private Dictionary<int, decimal> GetPays(DocumentTableIterator paysTable)
		{
			var paysAmount = new Dictionary<int, decimal>();
			while (paysTable.Read())
			{
				var payType = (int)paysTable["Тип оплаты"];
				decimal amount;
				paysAmount.TryGetValue(payType, out amount);
				paysAmount[payType] = amount + (decimal)paysTable["Сумма"];
			}
			return paysAmount;
		}

		private string[] GetCashInOutComments(DateTime start, DateTime end, int kkm, int shift)
		{
			var criteria = new DocumentsQueryTemplate(AppContext)
				.AddDocument("Изменение наличных в ККМ")
				.Select("Операция").Select("Комментарий")
				.Where("Дата", WhereOperation.GreatOrEqual, start)
				.Where("Дата", WhereOperation.LessOrEqual, end)
				.Where("ККМ", WhereOperation.Equal, kkm)
				.Where("Смена", WhereOperation.Equal, shift);
			var query = ExecuteQuery(criteria);

			var inComments = query.AsEnumerable()
				.Where(r => (int)r["Операция"] == 0 && !string.IsNullOrEmpty((string)r["Комментарий"]))
				.Select(r => (string)r["Комментарий"]).ToList();
			var outComments = query.AsEnumerable()
				.Where(r => (int)r["Операция"] == 1 && !string.IsNullOrEmpty((string)r["Комментарий"]))
				.Select(r => (string)r["Комментарий"]).ToList();

			return new[] { string.Join("; ", inComments), string.Join("; ", outComments) };
		}
	}
}
