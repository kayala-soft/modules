﻿using Kayala.Metadata.Fields;
using Kayala.Objects;
using Kayala.Query;
using Kayala.Services;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace PriceListService
{
	[Service("Прайс-лист")]
	public class PriceListReport : BaseService
	{
		[ServiceMethod]
		public void Load(out List<string> lines)
		{
			var pricesTypes = GetPricesTypes();
			lines = pricesTypes.Where(t => (bool)t["Использовать в РМК"]).Select(t => t.Name).ToList();
		}

		[ServiceMethod]
		public void Run(IEnumerable<string> lines, bool showWithoutPrice, bool showRests, IEnumerable<int> goods)
		{
			var pricesTypes = GetPricesTypes();
			if (pricesTypes.Count > 0 && (lines == null || !lines.Any()))
			{
				Context.Alert("Необходимо отметить хотя бы один тип цен продажи.");
				return;
			}
			const string dictName = "Товары";
			var goodsAny = goods != null && goods.Any();

			var criteria = (goodsAny
				? QueryHelper.GetAllCodes(AppContext, dictName, goods)
				: new QueryCriteria(dictName).Select("Code"))
				.WhereDictNotDeleted()
				.WhereDictIsNotGroup();
			var query = ExecuteQuery(criteria);
			var codes = goodsAny ? query.AsEnumerable().Select(r => (int)r["Code"]).ToList() : null;

			var defaultPrices = lines.Any() ? null : AppContext.Services.GetService<IPrices>().GetSalePrices(null, codes, null);
			var typesPrices = new Dictionary<string, Dictionary<int, decimal>>();
			foreach (var pricesType in pricesTypes.Where(t => lines.Contains(t.Name)))
			{
				var prices = AppContext.Services.GetService<IPrices>().GetSalePrices(null, codes, pricesType.Code);
				typesPrices.Add(pricesType.Name, prices);
			}
			if (!showWithoutPrice)
			{
				var goodsCodes = lines.Any() ? new HashSet<int>() : new HashSet<int>(defaultPrices.Keys);
				foreach (var line in lines.Where(typesPrices.ContainsKey))
				{
					foreach (var code in typesPrices[line].Keys)
						goodsCodes.Add(code);
				}
				criteria.WhereIn("Code", goodsCodes);
				query = ExecuteQuery(criteria);
			}
			query = query.BuildTree(new[] { new TreeGroup("Code", true) }, new string[0]);

			criteria = new QueryCriteria("Штрихкоды")
				.Select("Owner").Select("Name")
				.WhereDictNotDeleted();
			var barcodes = ExecuteQuery(criteria).AsEnumerable()
				.Select(r => new { Good = (int)r["Owner"], Barcode = (string)r["Name"] }).ToList();

			codes = query.AsEnumerable().Where(r => !r["Code"].IsNull() && !(bool)r["Code"]["ЭтоГруппа"]).Select(r => (int)r["Code"]).ToList();
			var goodsRests = showRests ? GetGoodsRests(codes) : null;

			var rep = CreateReport("PriceList.tcr");
			rep.AddSection("Шапка");
			rep.SetParameter("Дата", AppContext.NowDateTime.ToShortDateString());
			if (goodsAny)
				rep.SetParameter("Товары", "По товарам: " + QueryHelper.GetDictNames(AppContext, dictName, goods));
			rep.AddSection("Таблица");
			if (showRests)
				rep.JoinSection("ТаблицаОстаток");

			foreach (var line in lines.Where(typesPrices.ContainsKey))
			{
				rep.JoinSection("ТаблицаЦена");
				rep.SetParameter("Тип цен", line);
			}
			if (!lines.Any())
				rep.JoinSection("ТаблицаЦена");

			query.ProcessLevels((row, level, group) =>
			{
				if (group == null)
					return;

				var property = row[group.FieldName];
				var code = (int)property;

				rep.AddSection(level.ToString(CultureInfo.InvariantCulture));
				rep.SetParameter("Type", dictName);
				rep.SetParameter("Code", code);
				rep.SetSectionObject((DictionaryObject)property);
				var isElement = !(bool)property["ЭтоГруппа"];
				if (!isElement)
					rep.SetParameter("Style", "Bold");
				else
				{
					var barcode = string.Join(Environment.NewLine, barcodes.Where(b => b.Good == code).Select(b => b.Barcode));
					rep.SetParameter("Штрихкод", barcode);
				}
				if (showRests)
				{
					rep.JoinSection("Остаток");
					decimal qnt;
					goodsRests.TryGetValue(code, out qnt);
					rep.SetParameter("Кол", qnt);
					if (!isElement)
						rep.SetParameter("Style", "Bold");
				}
				foreach (var line in lines.Where(typesPrices.ContainsKey))
				{
					rep.JoinSection("Цена");
					if (isElement)
					{
						decimal price;
						typesPrices[line].TryGetValue(code, out price);
						rep.SetParameter("Цена", price);
					}
				}
				if (!lines.Any())
				{
					rep.JoinSection("Цена");
					if (isElement)
					{
						decimal price;
						defaultPrices.TryGetValue(code, out price);
						rep.SetParameter("Цена", price);
					}
				}
			});
			if (showRests)
			{
				rep.AddSection("Подвал");
				rep.JoinSection("ПодвалОстаток");
				decimal qnt;
				goodsRests.TryGetValue(0, out qnt);
				rep.SetParameter("Кол", qnt);
				foreach (var line in lines.Where(typesPrices.ContainsKey))
					rep.JoinSection("ПодвалЦена");
				if (!lines.Any())
					rep.JoinSection("ПодвалЦена");
			}
		}

		private List<DictionaryObject> GetPricesTypes()
		{
			var criteria = new QueryCriteria("Типы цен продажи")
				.WhereDictNotDeleted()
				.OrderByDesc("Использовать в РМК").OrderBy("Name");
			return ExecuteQuery(criteria).AsEnumerable().Select(r => (DictionaryObject)r.GetCurrent()).ToList();
		}

		private Dictionary<int, decimal> GetGoodsRests(IEnumerable<int> goods)
		{
			var criteria = CreateRestQuery("Остатки товаров")
				.Select("Товар")
				.Sum("Количество")
				.OnDate(AppContext.NowDateTime);
			if (goods != null && goods.Any())
				criteria.WhereIn("Товар", goods);

			return ExecuteQuery(criteria)
				.BuildTree(new[] { new TreeGroup("Товар", true) }, new[] { "Количество" })
				.AsEnumerable().ToDictionary(r => (int)r["Товар"], r => (decimal)r["Количество"]);
		}
	}

	public interface IPrices
	{
		Dictionary<int, decimal> GetSalePrices(DateTime? date, IEnumerable<int> goods, int? pricesType);
	}
}
