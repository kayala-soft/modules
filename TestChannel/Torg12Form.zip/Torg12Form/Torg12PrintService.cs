﻿using Kayala.Core;
using Kayala.Objects;
using Kayala.Services;

namespace Torg12FormService
{
	[Service]
    public class Torg12PrintService : BaseService
	{
		[ServiceMethod]
		public void Print(MethodContext context)
		{
			var doc = context.DocObject;
			var consts = AppContext.Repository.GetConstants();
			var rep = CreateReport("Торг12.tcr");

			rep.AddSection("ШапкаОбщая");
			rep.SetSectionObject(doc);
			rep.SetParameter("ДатаДок", doc.DocDateTime.ToShortDateString());

			var kpp = (string)consts["КПП"];
			if (!string.IsNullOrEmpty(kpp))
				rep.SetParameter("+КПП", $" КПП {kpp},");

			var contr = (DictionaryObject)doc["Контрагент"];
			if (contr != null)
			{
				kpp = (string)contr["КПП"];
				if (!string.IsNullOrEmpty(kpp))
					rep.SetParameter("+КонтрКПП", $" КПП {kpp},");
			}
			var pageNumber = 1;
			rep.AddSection("ШапкаСтраницы");
			rep.SetParameter("НомерСтраницы", "");

			const int rowsByPage = 48;
			const int rowsByPageHeader = 6;
			const int rowsByReportHeader = 15;
			const int rowsByFooter = 21;
			int footeredFullPage;
			int footerlessFullPage;

			var stringCount = doc.Tables[0].Count;

			int carryOverLastRow;
			// рассчитываем флаг переноса для первой страницы
			if (stringCount <= 6)
			{
				// все помещается
				carryOverLastRow = 0;
			}
			else
			{
				if (stringCount <= 26)
				{
					// последнюю строку надо перенести
					carryOverLastRow = 1;
				}
				else
				{
					footeredFullPage = (rowsByPageHeader + stringCount + rowsByFooter) / rowsByPage;
					footerlessFullPage = (rowsByPageHeader + stringCount - 1) / rowsByPage;
					carryOverLastRow = footeredFullPage - footerlessFullPage;
				}
			}
			// Итоги по странице
			var pageQuantity = 0m;
			var pageAmount = 0m;
			var pageVat = 0m;
			var pageSum = 0m;

			// Итоги по отчету
			var reportQuantity = 0m;
			var reportAmount = 0m;
			var reportVat = 0m;
			var reportSum = 0m;

			var rowNumber = 0;
			var printedRows = rowsByReportHeader + rowsByPageHeader; // напечатаны шапка отчета и шапка страницы

			var table = doc.Tables[0].CreateIterator();
			while (table.Read())
			{
				rowNumber++;
				var item = new
				{
					Good = (DictionaryObject)table["Товар"],
					Qnt = (decimal)table["Количество"],
					Price = (decimal)table["Цена"],
					Amount = (decimal)table["Сумма"]
				};

				// добавить шапку страницы
				if (printedRows == (rowsByPage - 1) || (carryOverLastRow == 1 && rowNumber == stringCount))
				{
					rep.AddSection("ИтогСтраницы");
					rep.SetParameter("ИтогоКоличествоНаСтранице", pageQuantity);
					rep.SetParameter("ИтогоСуммаБезНДСНаСтранице", pageAmount);
					rep.SetParameter("ИтогоНДСНаСтранице", pageVat);
					rep.SetParameter("ИтогоСНДСНаСтранице", pageSum);
					printedRows++;

					pageQuantity = 0;
					pageAmount = 0;
					pageVat = 0;
					pageSum = 0;
					pageNumber++;
					for (int i = printedRows; i < rowsByPage; i++)
					{
						rep.AddSection("Пустая секция");
					}
					rep.AddSection("ШапкаСтраницы");
					rep.SetParameter("НомерСтраницы", "Страница № " + pageNumber);
					printedRows = rowsByPageHeader;

					footeredFullPage = (rowsByPageHeader + (stringCount - rowNumber) +
						rowsByFooter) / rowsByPage;
					footerlessFullPage = (rowsByPageHeader + (stringCount - rowNumber) - 1) / rowsByPage;
					carryOverLastRow = footeredFullPage - footerlessFullPage;
				}

				// добавить секцию товара
				rep.AddSection("Товар");
				rep.SetParameter("НомСтр", rowNumber);
				rep.SetParameter("Наим", item.Good.Name);
				rep.SetParameter("КодТовара", item.Good.Code);
				rep.SetParameter("Единица", (string)item.Good["Единица измерения"]);
				rep.SetParameter("Количество", item.Qnt);
				rep.SetParameter("Цена", item.Price);
				rep.SetParameter("СуммаБезНДС", item.Amount);
				rep.SetParameter("СуммаСНДС", item.Amount);

				pageQuantity += item.Qnt;
				pageAmount += item.Amount;
				pageSum += item.Amount;

				reportQuantity += item.Qnt;
				reportAmount += item.Amount;
				reportSum += item.Amount;

				printedRows++;
			}
			rep.AddSection("ИтогСтраницы");
			rep.SetParameter("ИтогоКоличествоНаСтранице", pageQuantity);
			rep.SetParameter("ИтогоСуммаБезНДСНаСтранице", pageAmount);
			rep.SetParameter("ИтогоНДСНаСтранице", pageVat);
			rep.SetParameter("ИтогоСНДСНаСтранице", pageSum);

			rep.AddSection("ИтогНакладной");
			rep.SetParameter("ИтогоКоличество", reportQuantity);
			rep.SetParameter("ИтогоСуммаБезНДС", reportAmount);
			rep.SetParameter("ИтогоНДС", reportVat);
			rep.SetParameter("ИтогоСуммаСНДС", reportSum);

			rep.AddSection("ПодвалОбщий");
			string pgstr;
			if (10 < pageNumber && pageNumber < 20)
				pgstr = "листах";
			else
				pgstr = pageNumber % 10 == 1 ? "листе" : "листах";

			rep.SetParameter("ИнфоНакладной1", $"Товарная накладная имеет приложение на {pageNumber} {pgstr}");
			rep.SetParameter("КоличествоСтрокПрописью", NumberToString.GetString(stringCount, true, "", "", ""));
			rep.SetParameter("ВсегоНаименований", "Всего отпущено " +
				NumberToString.GetString(stringCount, true, "наименование", "наименования", "наименований"));
			rep.SetParameter("НаСумму", reportSum);
		}
	}
}
