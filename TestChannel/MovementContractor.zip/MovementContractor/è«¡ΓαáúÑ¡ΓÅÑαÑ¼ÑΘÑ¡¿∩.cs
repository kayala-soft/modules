﻿using Kayala.Events;
using Kayala.Metadata.Fields;
using Kayala.Objects;
using Kayala.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MovementContractor
{
	[Service]
    public class MovementContractorService : BaseService 
	{
		private const string DocName = "Перемещение товаров";

		[Event(DefaultEvents.ProcessDocument)]
		[ServiceMethod]
		public void ProcessDocument(MethodContext context)
		{
			if (!(context.EventData is ProcessDocumentEventData eventData) || eventData.Document.ObjectName != DocName)
				return;

			var doc = eventData.Document;
			if (doc.Status != DocumentStatus.Registered && eventData.ToStatus == DocumentStatus.Registered)
			{
				var contractor = doc["Контрагент"];
				var amount = (decimal)doc["Сумма доставки"];
				if (!contractor.IsNull())
				{
					if (amount > 0)
					{
						const int operation = 1;
						var debts = AppContext.Repository.CreateRegisterActions("Взаиморасчеты", doc);
						debts["Контрагент"] = contractor;
						debts["Долг фирмы"] = amount;
						debts["Операция"] = operation;
						debts.AddAction(RegisterAction.Income);
					}
					else
						context.Console.WriteWarning("Возможно следует указать стоимость доставки.");
				}
				else if (amount > 0)
				{
					context.Cancel("Необходимо указать контрагента или обнулить стоимость доставки.");
				}
			}
		}

		[ServiceMethod]
		[Param("EnterOn", FieldTypeId.LinkToAnyDocument)]
		public void EnterOnOutOrderByMovement(MethodContext context)
		{
			var basisDoc = (DocumentObject)context["EnterOn"];
			var doc = context.DocObject;
			var contractor = basisDoc["Контрагент"];
			doc.Amount = (decimal)basisDoc["Сумма доставки"];
			if (contractor.IsNull() || doc.Amount <= 0)
			{
				context.Alert("В документе-основании не указан контрагент и/или стоимость доставки.");
				context.Cancel("");
				return;
			}
			doc["Контрагент"] = contractor;
			doc["Комментарий"] = $"За доставку накладной № {basisDoc.Number} от {basisDoc.DocDateTime:d} г.";
		}

	}
}
