﻿using Kayala.Metadata.Fields;
using Kayala.Query;
using Kayala.Services;
using Kayala.UI;
using System.Linq;

namespace RepairOfGoodsServices
{
	[Service]
	public class RepairJournalsService : BaseService
	{
		[ServiceMethod]
		[Param("StartDate", FieldTypeId.DateTime)]
		[Param("EndDate", FieldTypeId.DateTime)]
		[Param("LastDate", FieldTypeId.DateTime, IsResult = true)]
		[Param("JournalControl", FieldTypeId.SystemObject)]
		[Param("Filter", FieldTypeId.SystemObject)]
		[Param("HideDeleted", FieldTypeId.Boolean)]
		[Param("VisibleColumns", FieldTypeId.SystemObject)]
		[Param("Result", FieldTypeId.SystemObject, IsResult = true)]
		public void GetJournal(MethodContext context)
		{
			var service = AppContext.Services.GetService("System");
			var systemContext = service.CreateContext("GetJournalData");

			context.CopyTo(systemContext);

			var journal = ((JournalControl)context["JournalControl"].GetValue()).Clone();
			systemContext["JournalControl"].SetValue(journal);
			systemContext["Filter"].SetValue(context["Filter"].GetValue());

			systemContext = service.Invoke(systemContext);

			var fromRepairTypeId = AppContext.Metadata.Documents.FirstOrDefault(m => m.ObjectName == "Выдача из ремонта")?.TypeId;

			var result = (QueryResult)systemContext["Result"].GetValue();
			result.ToBegin();
			while (result.Read())
			{
				var isFromRepair = (string)result["TypeId"] == fromRepairTypeId;
				if (isFromRepair)
				{
					var doc = result.GetCurrent();
					result["Устройство"] = doc["Прием в ремонт"]["Устройство"];
					result["Модель"] = doc["Прием в ремонт"]["Модель"];
					result["Дата готовности"] = doc["Прием в ремонт"]["Дата готовности"];
				}
			}
			context["Result"].SetValue(result);
			context["LastDate"] = systemContext["LastDate"];
		}
	}
}
