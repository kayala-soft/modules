﻿using Kayala.Events;
using Kayala.Objects;
using Kayala.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RepairOfGoodsServices
{
	[Service(DocName)]
	public class AcceptanceForRepairDoc : BaseService
	{
		private const string DocName = "Прием в ремонт";

		[ServiceMethod]
		public void CreateObject()
		{
			Context.DocObject["Телефон"] = Context.DocObject["Контрагент"]["Телефон"];
			Context.DocObject["Срок ремонта"] = 3;
		}

		[ServiceMethod]
		public void RepairDaysChanged()
		{
			var doc = Context.DocObject;
			doc["Дата готовности"] = doc.DocDateTime.Date.AddDays((int)doc["Срок ремонта"]);
		}

		[ServiceMethod]
		public void ReadyDateChanged()
		{
			var doc = Context.DocObject;
			if (doc == null)
				return;

			var days = ((DateTime)doc["Дата готовности"] - doc.DocDateTime.Date).Days;
			if ((int)doc["Срок ремонта"] != days)
				doc["Срок ремонта"] = days;
		}

		[Event(DefaultEvents.ProcessDocument)]
		[ServiceMethod]
		public void ProcessDocument(MethodContext context)
		{
			var eventData = context.EventData as ProcessDocumentEventData;
			if (eventData?.Document.ObjectName != DocName)
				return;

			var doc = eventData.Document;
			if (doc.Status == DocumentStatus.Registered || eventData.ToStatus != DocumentStatus.Registered)
				return;

			var errors = new StringBuilder();

			if (doc["Контрагент"].IsNull())
				errors.AppendLine(GetLocalString("#RepairOfGoods/NeedSelectCustomer"));

			if (doc["Устройство"].IsNull())
				errors.AppendLine(GetLocalString("#RepairOfGoods/NeedSelectDevice"));

			if (errors.Length > 0)
				context.Cancel(errors.ToString());
			
			var contractor = (DictionaryObject)doc["Контрагент"];
			if (!((string)contractor["Телефон"]).Contains((string)doc["Телефон"]))
			{
				contractor["Телефон"] = doc["Телефон"];
				AppContext.Repository.SaveChanges(contractor);
			}

			var reg = AppContext.Repository.CreateRegisterActions("Ремонты устройств", doc);
			reg["Прием в ремонт"] = doc.Code;
			reg["Количество"] = 1;
			reg.AddAction(RegisterAction.Income);
		}
	}
}
