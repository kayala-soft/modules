﻿using Kayala.Core;
using Kayala.Events;
using Kayala.Objects;
using Kayala.Services;
using Kayala.Query;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Kayala.Metadata.Fields;

namespace RepairOfGoodsServices
{
	[Service(DocName)]
	public class IssueFromRepairDoc : BaseService
	{
		private const string DocName = "Выдача из ремонта";

		[ServiceMethod]
		[Param("EnterOn", FieldTypeId.LinkToAnyDocument)]
		public void EnterOn(MethodContext context)
		{
			var basisDoc = (DocumentObject)context["EnterOn"];
			var doc = context.DocObject;
			doc["Контрагент"] = basisDoc["Контрагент"];
			List<KDataRow> acceptanceList = null;
			FillAcceptanceList(out acceptanceList);
			if (acceptanceList.Count > 0)
			{
				doc["Прием в ремонт"] = (Guid)acceptanceList[0]["Code"];
			}
		}
		
		[ServiceMethod]
		public void FillAcceptanceList(out List<KDataRow> acceptanceList)
		{
			acceptanceList = new List<KDataRow>();

			var doc = Context.DocObject;
			var criteria = new QueryCriteria("Ремонты устройств", true)
				.Select("Прием в ремонт")
				.Where("[Количество] > 0");
			var rows = ExecuteQuery(criteria).AsEnumerable()
				.Where(r => (int)r["Прием в ремонт"]["Контрагент"] == (int)doc["Контрагент"])
				.ToList();
			if (rows.Count == 0)
			{
				var msg = string.Format(GetLocalString("#RepairOfGoods/MissingAcceptanceByContractor"), doc["Контрагент"]);
				Context.Alert(msg);
				Context.Cancel("");
				return;
			}
			if (rows.Count == 1)
				doc["Прием в ремонт"] = rows[0]["Прием в ремонт"];
			else
			{
				foreach (var row in rows)
				{
					var acceptance = (DocumentObject)row["Прием в ремонт"];
					var item = new KDataRow(3);
					item["Code"] = acceptance.Code;
					item["Name"] = $"{acceptance.Number} от {acceptance.DocDateTime}";
					item["Device"] = GetDeviceText(acceptance);
					acceptanceList.Add(item);
				}
			}
		}

		[ServiceMethod]
		public void SetAcceptanceDoc(List<KDataRow> acceptanceList, int acceptanceIndex)
		{
			if (-1 < acceptanceIndex && acceptanceIndex < acceptanceList?.Count)
			{
				Context.DocObject["Прием в ремонт"] = (Guid)acceptanceList[acceptanceIndex]["Code"];
			}
		}

		private string GetDeviceText(DocumentObject acceptance)
		{
			return $"{acceptance["Устройство"]} {acceptance["Модель"]} {GetLocalString("#RepairOfGoods/Serial№")} {acceptance["Серийный номер"]}";
		}

		[ServiceMethod]
		public void Load(out string acceptanceText, out string deviceText, out string malfunctionText)
		{
			acceptanceText = "";
			deviceText = "";
			malfunctionText = "";
			var acceptance = (DocumentObject)Context.DocObject["Прием в ремонт"];
			if (acceptance == null)
				return;
			
			acceptanceText = acceptance.ToString();
			deviceText = GetDeviceText(acceptance);
			malfunctionText = (string)acceptance["Неисправность"];
		}

		[ServiceMethod]
		public void OpenAcceptanceDoc()
		{
			var acceptance = (DocumentObject)Context.DocObject["Прием в ремонт"];
			if (acceptance != null)
				Context.ObjectsForOpen.Add(acceptance);
		}


		[Event(DefaultEvents.ProcessDocument)]
		[ServiceMethod]
		public void ProcessDocument(MethodContext context)
		{
			var eventData = context.EventData as ProcessDocumentEventData;
			if (eventData?.Document.ObjectName != DocName)
				return;

			var doc = eventData.Document;
			if (doc.Status == DocumentStatus.Registered || eventData.ToStatus != DocumentStatus.Registered)
				return;

			var errors = new StringBuilder();

			if (doc["Контрагент"].IsNull())
				errors.AppendLine(GetLocalString("#RepairOfGoods/NeedSelectCustomer"));

			if (doc["Прием в ремонт"].IsNull())
				errors.AppendLine(GetLocalString("#RepairOfGoods/NeedSelectAcceptance"));

			if (errors.Length > 0)
				context.Cancel(errors.ToString());

			var reg = AppContext.Repository.CreateRegisterActions("Ремонты устройств", doc);
			reg["Прием в ремонт"] = doc["Прием в ремонт"];
			reg["Количество"] = 1;
			reg["Сумма продажи"] = doc.Amount;
			reg.AddAction(RegisterAction.Outcome);
		}
	}
}
