﻿using System;
using System.Collections.Generic;
using System.Linq;
using Kayala;
using Kayala.Core;
using Kayala.Database;
using Kayala.Metadata;
using Kayala.Metadata.Fields;
using Kayala.Objects;
using Kayala.Query;
using Kayala.Services;

namespace MoveDataService
{
	[Service]
	public class TransferDataService : BaseService
	{
		public interface IPrices
		{
			Dictionary<int, decimal> GetSalePrices(DateTime? date, IEnumerable<int> goods, int? pricesType);
		}

		[ServiceMethod]
		public void Load(out string[] sourceTypes)
		{
			sourceTypes = new[]
			{
				DatabaseAccessor.SQLiteProvider,
				DatabaseAccessor.LocalDbProvider,
				DatabaseAccessor.MsSqlProvider,
				DatabaseAccessor.PostgresSqlProvider,
			};
		}

		[ServiceMethod]
		public void LoadAdv(out string[] dictNames, out string[] docNames, out string[] regNames)
		{
			dictNames = AppContext.Metadata.DictionariesInSafeOrder
					.Select(d => d.ObjectName)
					.ToArray();

			docNames = AppContext.Metadata.Documents
					.OrderBy(d => d.Fields.Count(f => f is DocumentField) + d.Tables.Sum(t => t.Fields.Count(ft => ft is DocumentField)))
					.Select(d => d.ObjectName)
					.ToArray();

			regNames = AppContext.Metadata.Registers.Select(d => d.ObjectName).OrderBy(d => d).ToArray();
		}

		private bool CheckModules(KAppContext sourceContext)
		{
			var moveDataModuleId = Guid.Parse("7b1c0954-2f0b-44d9-9dd1-1d8fd276330a");
			var installed = AppContext.Modules.InstalledModules.Where(m => m.Id != moveDataModuleId).Select(m => m.Id);
			var sourceInstalled = sourceContext.Modules.InstalledModules.Where(m => m.Id != moveDataModuleId).Select(m => m.Id);

			var result = installed.Count() == sourceInstalled.Count();

			if (!result)
			{
				var detail = string.Empty;
				var notFound = sourceInstalled.Where(s => !installed.Contains(s)).ToList();
				if (notFound.Any())
				{
					detail = "В текущей базе не установлены: " + Environment.NewLine 
							+ string.Join(Environment.NewLine, sourceContext.Modules.InstalledModules.Where(m => notFound.Contains(m.Id)).Select(m => m.Name).ToArray())
							+ Environment.NewLine
							+ Environment.NewLine;
				}
				notFound = installed.Where(s => !sourceInstalled.Contains(s)).ToList();
				if (notFound.Any())
				{
					detail += "В исходной базе не установлены: " + Environment.NewLine 
							+ string.Join(Environment.NewLine, AppContext.Modules.InstalledModules.Where(m => notFound.Contains(m.Id)).Select(m => m.Name).ToArray());
				}
				Context.Console.WriteError("Не совпадает набор установленных модулей в целевой и исходной базе.", detail);
			}

			return result;
		}

		private Dictionary<string, Dictionary<int, int>> ProcessDictionaries(string[] dictNames, KAppContext sourceContext, bool createNewDict)
		{
			var dicts = new Dictionary<string, Dictionary<int, int>>();
			foreach (var dictName in dictNames)
			{
				var codesDict = new Dictionary<int, int>();
				dicts.Add(dictName, codesDict);

				var metadata = AppContext.Metadata.GetDictionary(dictName);

				var position = 0;
				var totalCount = DataConverter.ToInt32(sourceContext.Data.ExecuteScalar($"select count(*) from {metadata.TableName} where {metadata.DeletedField.DbFieldName} = @Deleted", false));

				if (metadata.CountOfLevels == 0)
				{
					var criteria = new QueryCriteria(metadata.ObjectName);
					ProcessDictionaryCriteria(dicts, criteria, sourceContext, metadata, createNewDict, totalCount, ref position);
				}
				else
				{
					for (var i = 0; i <= metadata.CountOfLevels; i++)
					{
						var criteria = new QueryCriteria(metadata.ObjectName)
							.OrderByDesc(metadata.IsGroupField.FieldName);
						
						if (i < metadata.CountOfLevels)
						{
							criteria.Where($"Parent{i + 1} is null");
						}

						if (i > 0)
						{
							criteria.Where($"Parent{i} is not null");
						}
						
						ProcessDictionaryCriteria(dicts, criteria, sourceContext, metadata, createNewDict, totalCount, ref position);
					}
				}

				var maxCode = DataConverter.ToInt32(sourceContext.Data.ExecuteScalar($"SELECT MAX({metadata.CodeField.DbFieldName}) FROM {metadata.TableName};"));
				AppContext.Numerator.Set(metadata.TableName, maxCode);
			}

			return dicts;
		}

		private void ProcessDictionaryCriteria(Dictionary<string, Dictionary<int, int>> dicts, 
													QueryCriteria criteria, 
													KAppContext sourceContext, 
													DictionaryMetadata metadata, 
													bool createNewDict,
													int totalCount,
													ref int position)
		{
			criteria.Select(metadata.CodeField.FieldName)
				.OrderBy(metadata.CodeField.FieldName);

			var result = sourceContext.Repository.ExecuteQuery(criteria);
			var codesDict = dicts[metadata.ObjectName];
			while(result.Read())
			{
				position++;

				var sourceCode = (int)result[metadata.CodeField.FieldName];
				var dict = MoveDictionary(dicts, sourceContext, metadata, sourceCode, createNewDict);
				if (dict != null)
				{
					codesDict.Add(sourceCode, dict.Code);
				}

				if (result.Position % 10 == 0)
				{
					Context.WriteStatus($"{metadata.ObjectName} {position}/{totalCount}", position, totalCount);
				}
			}
		}

		private DictionaryObject MoveDictionary(Dictionary<string, Dictionary<int, int>> dicts,
												KAppContext sourceContext, 
												DictionaryMetadata metadata, 
												int sourceCode, 
												bool createNewDict)
		{
			DictionaryObject newDict = null;
			if (createNewDict)
			{
				newDict = AppContext.Repository.CreateDictionaryItem(metadata.ObjectName);
			}
			else
			{
				newDict = AppContext.Repository.GetDictionaryItem(metadata.ObjectName, sourceCode) ?? AppContext.Repository.CreateDictionaryItem(metadata.ObjectName);
				newDict.Code = sourceCode;
			}

			var sourceDict = sourceContext.Repository.GetDictionaryItem(metadata.ObjectName, sourceCode);
			if (sourceDict == null)
			{
				return null;
			}

			foreach (var field in metadata.Fields.Where(f => !f.LikeIs(metadata.CodeField.FieldName)))
			{
				var dictionaryField = field as DictionaryField;
				if (dictionaryField != null)
				{
					Dictionary<int, int> codes = null;
					int refCode = 0;
					if (dicts.TryGetValue(dictionaryField.DictionaryName, out codes) && codes.TryGetValue((int)sourceDict[field.FieldName], out refCode))
					{
						newDict[field.FieldName] = refCode;
					}
				}
				else
				{
					newDict[field.FieldName] = sourceDict[field.FieldName];
				}
			}
			try
			{
				AppContext.Repository.SaveChanges(newDict);
			}
			catch (Exception ex)
			{
				newDict = null;
				AppContext.Log.WriteError(ex);
			}

			try
			{
				if (newDict != null)
				{
					if (metadata.AttachmentMetadata != null)
					{
						var attachments = sourceContext.Repository.GetAllAttachments(metadata.ObjectName, sourceCode);
						var existsAttachments = AppContext.Repository.GetAllAttachments(metadata.ObjectName, sourceCode);
						foreach(var attachment in attachments)
						{
							var newAttachment = existsAttachments.FirstOrDefault(a => a.Code == attachment.Code) ?? AppContext.Repository.CreateAttachment(metadata.ObjectName);
							foreach (var field in metadata.AttachmentMetadata.Fields)
								newAttachment[field.FieldName] = attachment[field.FieldName];
							
							newAttachment[metadata.AttachmentMetadata.OwnerField] = newDict.Code;
							AppContext.Repository.SaveChanges(newAttachment);
						}
					}
				}
			}
			catch (Exception ex)
			{
				AppContext.Log.WriteError(ex);
			}

			return newDict;
		}

		[ServiceMethod]
		public void RunSimple(string selectedSourceType, string sourceServer, bool useLogBase, 
			string sourceDatabase, string sourceLogin, string sourcePassword, 
			bool createNewDicts, bool moveRests, bool movePrices)
		{
			var dictNames = AppContext.Metadata.DictionariesInSafeOrder
					.Select(d => d.ObjectName)
					.ToArray();

			var sourceContext = GetSourceContext(selectedSourceType, sourceServer, sourceDatabase, sourceLogin, sourcePassword, useLogBase);
			if (sourceContext == null)
				return;

			if (!CheckModules(sourceContext))
			{
				return;
			}

			//System.Diagnostics.Debugger.Break();
			
			var dicts = ProcessDictionaries(dictNames, sourceContext, createNewDicts); new Dictionary<string, Dictionary<int, int>>();
			
			if (moveRests)
			{
				var criteria = CreateRestQuery("Остатки товаров")
					.Select("Склад")
					.Select("Товар")
					.Sum("Количество")
					.Sum("Сумма")
					.OnDate(AppContext.NowDateTime);

				var result = sourceContext.Repository.ExecuteQuery(criteria)
					.BuildTree(new[] { new TreeGroup("Склад", false), new TreeGroup("Товар", false) }, new[] { "Количество", "Сумма" });

				var goodsDict = dicts["Товары"];
				var storeDict = dicts["Склады"];
				DocumentObject income = null;
				result.ProcessLevels((r, level, group) => 
				{
					if (group == null)
					{
						return;
					}

					if (group.FieldName == "Склад")
					{
						if (income != null && income.Tables[0].Count > 0)
						{
							AppContext.Repository.SaveChanges(income);
						}

						int storeCode = 0;
						if (storeDict.TryGetValue((int)r["Склад"], out storeCode))
						{
							income = AppContext.Repository.CreateDocument("Приход товаров");
							income.GenerateNumber();
							const int izlishki = 2;
							income["Операция"] = izlishki;
							income["Склад"] = storeCode;
						}
						else
						{
							income = null;
						}
					}
					if (group.FieldName == "Товар")
					{
						var goodCode = 0;
						if (goodsDict.TryGetValue((int)r["Товар"], out goodCode))
						{
							var sum = (decimal)r["Сумма"];
							var quantity = (decimal)r["Количество"];
							if (quantity != 0)
							{
								income.Tables[0].Add();
								income.Tables[0]["Товар"] = goodCode;
								income.Tables[0]["Количество"] = quantity;
								income.Tables[0]["Цена"] = sum / quantity;
								income.Tables[0]["Сумма"] = sum;

								income.Amount += sum;
							}
						}
					}
				});

				if (income != null && income.Tables[0].Count > 0)
				{
					AppContext.Repository.SaveChanges(income);
				}
			}

			if (movePrices)
			{
				var criteria = new QueryCriteria("Типы цен продажи")
					.WhereDictNotDeleted()
					.OrderByDesc("Использовать в РМК")
					.OrderBy("Name");
			 	var sourcePriceTypes = sourceContext.Repository.ExecuteQuery(criteria)
				 	.AsEnumerable()
					.Select(r => (DictionaryObject)r.GetCurrent())
					.ToList();
				
				var goodsDict = dicts["Товары"];
				var priceTypesDict = dicts["Типы цен продажи"];
				if (!sourcePriceTypes.Any())
				{
					sourcePriceTypes.Add(null);
				}

				foreach (var priceType in sourcePriceTypes)
				{
					var pricing = AppContext.Repository.CreateDocument("Ценообразование");
					pricing.GenerateNumber();
					int priceTypeCode = 0;
					if (priceType != null && !(bool)priceType["Использовать в РМК"] && priceTypesDict.TryGetValue(priceType.Code, out priceTypeCode))
					{
						pricing["Тип цен"] = priceTypeCode;
					}

					var prices = sourceContext.Services.GetService<IPrices>().GetSalePrices(null, null, priceType?.Code);
					foreach (var pair in prices)
					{
						var goodCode = 0;
						if (goodsDict.TryGetValue(pair.Key, out goodCode) && pair.Value > 0)
						{
							pricing.Tables[0].Add();
							pricing.Tables[0]["Товар"] = goodCode;
							pricing.Tables[0]["Цена продажи"] = pair.Value;
						}
					}

					if (pricing.Tables[0].Count > 0)
					{
						AppContext.Repository.SaveChanges(pricing);
					}
				}
			}

			Context.Alert("Загрузка выполнена");
		}

		[ServiceMethod]
		public void RunDict(string selectedSourceType, string sourceServer, bool useLogBase, string sourceDatabase, string sourceLogin, string sourcePassword, string[] selectedDictNames)
		{
			if (selectedDictNames?.Any() == false)
			{
				Context.Console.Write("Необходимо выбрать справочники для переноса.");
				return;
			}

			var sourceContext = GetSourceContext(selectedSourceType, sourceServer, sourceDatabase, sourceLogin, sourcePassword, useLogBase);
			if (sourceContext == null)
				return;

			if (!CheckModules(sourceContext))
			{
				return;
			}
			
			ProcessDictionaries(selectedDictNames, sourceContext, false);

			Context.Alert("Загрузка справочников выполнена");
		}

		[ServiceMethod]
		public void RunDocs(string selectedSourceType, string sourceServer, bool useLogBase, string sourceDatabase, string sourceLogin, string sourcePassword, 
			[DefaultDate(DateForGenerate.Today)]DateTime startDate,
			[DefaultDate(DateForGenerate.EndOfToday)]DateTime endDate,
			string[] selectedDocNames)
		{
			if (selectedDocNames?.Any() == false)
			{
				Context.Console.Write("Необходимо выбрать документы для переноса.");
				return;
			}

			Context.Console.Write("Всего документов " + AppContext.Metadata.Documents.Count());
			var sourceContext = GetSourceContext(selectedSourceType, sourceServer, sourceDatabase, sourceLogin, sourcePassword, useLogBase);
			if (sourceContext == null)
				return;

			if (!CheckModules(sourceContext))
			{
				return;
			}

			foreach (var docName in selectedDocNames)
			{
				var metadata = AppContext.Metadata.Documents.First(m => m.ObjectName == docName);

				var criteria = new DocumentsQueryTemplate(AppContext)
					.AddDocument(docName)
					.Select(AppContext.Metadata.CommonDocuments.DocCodeField.DbFieldName);

				var guids = AppContext.Repository.ExecuteQuery(criteria).AsEnumerable()
					.Select(r => DataConverter.ToGuid(r[AppContext.Metadata.CommonDocuments.DocCodeField.DbFieldName].GetValue()));
				var existCodes = new HashSet<Guid>(guids);

				var sourceCriteria = new DocumentsQueryTemplate(sourceContext)
						.AddDocument(docName)
						.Where(AppContext.Metadata.CommonDocuments.DocDateTimeField.DbFieldName, WhereOperation.GreatOrEqual, startDate)
						.Where(AppContext.Metadata.CommonDocuments.DocDateTimeField.DbFieldName, WhereOperation.LessOrEqual, endDate);

				if (existCodes.Count > 0)
					sourceCriteria.Where(AppContext.Metadata.CommonDocuments.DocCodeField.DbFieldName, WhereOperation.NotIn, existCodes);

				var query = sourceContext.Repository.ExecuteQuery(sourceCriteria);
				Context.Console.Write(docName + " " + query.Count);
				while (query.Read())
				{
					var srcDoc = (DocumentObject)query.GetCurrent();
					var doc = AppContext.Repository.CreateDocument(docName);
					doc.Code = srcDoc.Code;
					foreach (var field in AppContext.Metadata.CommonDocuments.Fields)
						doc[field.FieldName] = srcDoc[field.FieldName];

					doc[AppContext.Metadata.CommonDocuments.AuthorField.DbFieldName] = AppContext.Users.CurrentUser.Code;
					foreach (var field in metadata.Fields)
						doc[field.FieldName] = srcDoc[field.FieldName];
					for (int i = 0; i < metadata.Tables.Count; ++i)
					{
						doc.Tables[i].Clear();
						var srcTable = srcDoc.Tables[i].CreateIterator();
						while (srcTable.Read())
						{
							doc.Tables[i].Add();
							foreach (Field field in metadata.Tables[i].Fields)
								doc.Tables[i][field.FieldName] = srcTable[field.FieldName];
						}
					}
					try
					{
						AppContext.Repository.SaveChanges(doc);

						var numeratorParts = srcDoc.Number.Split('-');
						var numerator = numeratorParts[0] + '-';
						AppContext.Numerator.Set(numerator, sourceContext.Numerator.Get(numerator));
					}
					catch (Exception ex)
					{
						Context.Console.Write(docName + " (" + doc.Code + ")" + ex.Message);
					}
					if (query.Position % 10 == 0)
						Context.WriteStatus(docName, query.Position, query.Count);
				}
			}
			Context.Alert("Загрузка документов выполнена");
		}

		[ServiceMethod]
		public void RunRegs(string selectedSourceType, string sourceServer, bool useLogBase, string sourceDatabase, string sourceLogin, string sourcePassword,
			[DefaultDate(DateForGenerate.Today)]DateTime regStartDate,
			[DefaultDate(DateForGenerate.EndOfToday)]DateTime regEndDate,
			string[] selectedRegNames)
		{
			if (selectedRegNames?.Any() == false)
			{
				Context.Console.Write("Необходимо выбрать регистры для переноса.");
				return;
			}

			var sourceContext = GetSourceContext(selectedSourceType, sourceServer, sourceDatabase, sourceLogin, sourcePassword, useLogBase);
			if (sourceContext == null)
				return;

			if (!CheckModules(sourceContext))
			{
				return;
			}

			var docMetadata = AppContext.Metadata.CommonDocuments;
			foreach (var regName in selectedRegNames)
			{
				var metadata = AppContext.Metadata.Registers.First(m => m.ObjectName == regName);

				var row = sourceContext.Data.ExecuteToOne($"SELECT MIN({metadata.DateTimeField}) as mindate FROM {metadata.TableName} WHERE {metadata.DateTimeField} >= @start", regStartDate);
				if (DataConverter.ToDateTime(row["mindate"]) == DateHelper.MinDateTime)
				{
					continue;
				}
				var minDate = DataConverter.ToDateTime(row["mindate"]).Date;
				var count = (regEndDate - minDate).Days;
				var i = 0;
				while (minDate <= regEndDate)
				{
					i++;
					var existDocs = AppContext.Data
							.ExecuteToList($"SELECT {docMetadata.DocCodeField.DbFieldName} FROM {docMetadata.TableName} WHERE {docMetadata.DocDateTimeField.DbFieldName} >= @start and {docMetadata.DocDateTimeField.DbFieldName} < @end", minDate, minDate.AddDays(1))
							.Select(c => DataConverter.ToGuid(c[docMetadata.DocCodeField.DbFieldName])).ToList();
					if (existDocs.Count == 0)
					{
						minDate = minDate.AddDays(1);
						continue;
					}
					var reg = AppContext.Repository.CreateRegisterActions(regName, null);
					var actions = sourceContext.Data
							.ExecuteToList($"SELECT * FROM {metadata.TableName} WHERE {metadata.DateTimeField} >= @start and {metadata.DateTimeField} < @end and {metadata.DocumentField} IN ARRAY(@docs)",
							minDate, minDate.AddDays(1), existDocs);
					foreach (var dataRow in actions)
					{
						var docCode = DataConverter.ToGuid(dataRow[metadata.DocumentField]);

						foreach (var field in metadata.Fields)
							reg[field.FieldName].SetValue(dataRow[field.DbFieldName]);
						reg[metadata.DocumentField] = docCode;
						reg[metadata.DateTimeField] = DataConverter.ToDateTime(dataRow[metadata.DateTimeField]);
						if ((RegisterAction)DataConverter.ToInt32(dataRow[metadata.ActionField]) == RegisterAction.Outcome)
						{
							foreach (var resourceField in metadata.ResourceFields)
							{
								reg[resourceField.FieldName] = -DataConverter.ToDecimal(dataRow[resourceField.DbFieldName]);
							}
						}
						reg.AddAction((RegisterAction)DataConverter.ToInt32(dataRow[metadata.ActionField]));
					}
					try
					{
						AppContext.Repository.SaveChanges(reg);
					}
					catch (Exception ex)
					{
						Context.Console.Write(regName + " " + minDate + " " + ex.Message);
					}
					minDate = minDate.AddDays(1);

					Context.WriteStatus(regName, i, count);
				}
			}
			Context.Alert("Загрузка регистров выполнена.");
		}

		private KAppContext GetSourceContext(string selectedSourceType, string sourceServer, string sourceDatabase, string sourceLogin, string sourcePassword, bool useLogBase)
		{
			if (string.IsNullOrEmpty(sourceDatabase))
			{
				Context.Console.WriteWarning("Необходимо указать базу данных. Обработка прервана.");
				return null;
			}

			if (selectedSourceType == DatabaseAccessor.MsSqlProvider || selectedSourceType == DatabaseAccessor.PostgresSqlProvider)
			{
				if (string.IsNullOrEmpty(sourceServer))
				{
					Context.Console.WriteWarning("Необходимо указать сервер. Обработка прервана.");
					return null;
				}

				if (string.IsNullOrEmpty(sourceLogin))
				{
					Context.Console.WriteWarning("Необходимо указать логин. Обработка прервана.");
					return null;
				}
			}

			var connStrBuilder = new ConnectionStringBuilder(selectedSourceType)
			{
				Server = sourceServer,
				Database = sourceDatabase,
				Login = sourceLogin,
				Password = sourcePassword,
				UseLogDatabase = useLogBase
			};

			KAppContext result = null;
			try
			{
				result = CreateAppContext(connStrBuilder.BuildString(), "MoveDataContext");
				if (result != null)
				{
					KApp.AddContext(result);
				}
			}
			catch (Exception ex)
			{
				WriteErrorToLog(ex);
			}

			if (result == null)
				Context.Console.WriteWarning("Ошибка при создании контекста подключения. Обработка прервана.");

			return result;
		}
	}
}
